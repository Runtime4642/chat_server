import React from 'react';
import NoticeList from './NoticeList';

const Notice = () => {
    return(
        <div>
            <NoticeList/>
        </div>

    );
};

export default Notice;