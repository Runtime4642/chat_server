import React from 'react';
import TimeList from './TimeList';

const Time = () => {
    return(
        <div>
            <TimeList />
        </div>

    );
};

export default Time;