import React, {Component} from "react";
import {connect} from "react-redux";
import moment from "moment";
import * as commuteActions from "store/modules/commute";
import * as headerActions from "store/modules/Header";
import * as timeActions from "store/modules/time";
import {bindActionCreators} from "redux";

let timer = null;

class TimeList extends Component {
    state = {
        timeset: " "
    };
    getTime = () => {
        const hour = moment().format("HH");
        const minute = moment().format("mm");
        const second = moment().format("ss");
        const timeset = `${hour > 9 ? hour : `0${hour}`}:${minute > 9 ? minute : `0${minute}`}:${second > 9 ? second : `0${second}`}`;
        this.setState({
            timeset
        });
    };

    componentWillMount() {
        let cnt = 0;
        const {auth, CommuteActions, token, loginUserNo, TimeActions} = this.props;
        let name = "goto";
        let value = false;
        CommuteActions.changeInput({name, value});
        name = "gooff";
        value = false;
        CommuteActions.changeInput({name, value});
        name = "starttime"
        value = "";
        TimeActions.changeInput({name, value});
        name = "endtime"
        value = "";
        TimeActions.changeInput({name, value});

        if (auth === 'ROLE_USER') {
            timer = setInterval(() => {
                const {endtime, starttime, goto, gooff} = this.props;

                cnt++;
                if (starttime === "" && goto) {
                    TimeActions.getStartTime(loginUserNo, token);
                }
                // //console.log(goto);
                // //console.log(starttime);
                // //console.log(endtime);
                // //console.log(gooff);
                if (starttime !== "" && endtime === "" && gooff) {
                    TimeActions.getTotalWorkTime(loginUserNo, token);
                    TimeActions.getTodayCommuteEndTime(loginUserNo, token);
                    clearInterval(timer);
                }

                CommuteActions.changeInput({name: 'cnt', value: cnt});
                this.tick();
               // //console.log("인터벌~");
                if (!sessionStorage.getItem("id_token")) {

                    clearInterval(timer);

                }
            }, 1000);
        }
    }

    convertState(name, value) {
        const {CommuteActions} = this.props;

        CommuteActions.stateChange({name, value});
    }

    tick = () => {
        const {endTime, preGoTo, preGoOff, preHoliDay, language} = this.props;

        this.convertState('time', new Date());

        const now = moment(new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate()) + " " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds(), 'YYYY-MM-DD HH:mm:ss');
        const end = moment(new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate()) + " " + endTime, 'YYYY-MM-DD HH:mm:ss');
        const night = moment(new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + (new Date().getDate() + 1) + " " + "00:00:00", 'YYYY-MM-DD HH:mm:ss')

        // //console.log(now);
        // //console.log(end);
        // //console.log(night);
        // //console.log(endTime);

        if (!preGoTo && preGoOff) {
            this.convertState('preGoTo', true);
        }

        if ((now.isoWeekday() === 1) || (preHoliDay === true)) {
            this.convertState('preGoTo', true);
            this.convertState('preGoOff', true);
        }

        if (now.isAfter(night)) {
            //console.log("same");
            this.convertState('isNight', true);
        }

        if (now.isAfter(end)) {
            //console.log("after");
            this.convertState('isGoOff', true);
            this.convertState('isNigiht', false);
        }

        if (now.isBefore(end)) {
            //console.log("before");
            this.convertState('isGoOff', false);
            this.convertState("isNight", false);
        }
    }

    render() {
        let now = moment().format('HH:mm:ss');
        const {totalWorkTime, starttime, time1, endtime, goto} = this.props;
        //console.log(starttime);
       // //console.log(goto);
       // //console.log("랜더")
       // //console.log(time1);
        let timeset;
        if (starttime === "") {
            timeset = '00:00:00';
        } else if (starttime !== "") {

            const selectstarttime = moment(time1, "HH:mm:ss");
            const pushnow = moment(now, "HH:mm:ss");
            const pushstarttime = moment(starttime, "HH:mm:ss");
            const timediff = selectstarttime.diff(pushnow, "seconds"); //시간
            const timediff2 = selectstarttime.diff(pushstarttime, "seconds"); //시간
            // //console.log(timediff);
            if (timediff > 0) {
                timeset = "00:00:00";
                //console.log("@@");
            } else {
                let secondsDiff;
              //  //console.log(timediff2);
                if (timediff2 > 0) {
                    const startdt = moment(now, "HH:mm:ss");
                    const enddt = moment(time1, "HH:mm:ss");
                    secondsDiff = startdt.diff(enddt, "seconds");
                } else {
                    const startdt = moment(now, "HH:mm:ss");
                    const enddt = moment(starttime, "HH:mm:ss");
                    secondsDiff = startdt.diff(enddt, "seconds");
                }
                const latehour = Math.floor(secondsDiff / 3600)
                const latemin = Math.floor((secondsDiff - (latehour * 3600)) / 60)
                const latesec = (secondsDiff - (latehour * 3600) - (latemin * 60))

                if (secondsDiff < 0) {
                    timeset = "00:00:00"
                } else {
                    //   //console.log("@@@@");
                    timeset = `${latehour > 9 ? latehour : `0${latehour}`}:${latemin > 9 ? latemin : `0${latemin}`}:${latesec > 9 ? latesec : `0${latesec}`}`;
                }
            }

        }
        if (endtime === "")
            return <div>{timeset}</div>;
        else
            return <div>{totalWorkTime}</div>;
    }
}

export default connect(
    state => ({
        loginUserNo: state.login.no,
        token: state.login.token,
        auth: state.login.auth,
        no: state.list.get("no"),
        lasttime: state.commute.get("lasttime"),
        cnt: state.commute.get('cnt'),
        preGoTo: state.commute.get("preGoTo"),
        preGoOff: state.commute.get("preGoOff"),
        preHoliDay: state.holiday.get("preHoliDay"),
        goto: state.commute.get("goto"),
        gooff: state.commute.get("gooff"),
        endTime: state.commute.get("endTime"),
        totalWorkTime: state.time.get("totalWorkTime"),
        starttime: state.time.get("starttime"),
        time: state.time.get("time"),
        start: state.time.get("start"),
        end: state.time.get("end"),
        time1: state.time.get("time1"),
        endtime: state.time.get("endtime")
    }),
    dispatch => ({
        CommuteActions: bindActionCreators(commuteActions, dispatch),
        HeaderActions: bindActionCreators(headerActions, dispatch),
        TimeActions: bindActionCreators(timeActions, dispatch)

    })
)(TimeList);