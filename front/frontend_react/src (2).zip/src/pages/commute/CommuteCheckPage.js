import React from 'react';
import CommuteCheckContainer from 'containers/commute/CommuteCheckContainer';;

const CommuteCheckPage = () => {
    return (
        <CommuteCheckContainer/>
    );
};

export default CommuteCheckPage;