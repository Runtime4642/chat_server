import React from "react";
import AddContainer from "containers/workAttitude/AddContainer";

const AddPage = () => {
  return (
    <div>
      <AddContainer />
    </div>
  );
};

export default AddPage;
