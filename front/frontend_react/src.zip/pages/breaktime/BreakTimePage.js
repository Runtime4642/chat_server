import React from 'react';
import BreakTimeContainer from 'containers/service/BreakTimeContainer';
import BreakTimeListContainer from 'containers/service/BreakTimeListContainer';
import BreakTimePaginationContainer from 'containers/service/BreakTimePaginationContainer';
import BreakTimeModalContainer from 'containers/modal/BreakTimeModalContainer';

const WorkTimePage = () => {
    return (
        <div>
            <BreakTimeContainer/>
            <BreakTimeListContainer/>
            <BreakTimePaginationContainer/>
            <BreakTimeModalContainer/>
        </div>
    );
};

export default WorkTimePage;