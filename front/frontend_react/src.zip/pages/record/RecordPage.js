import React from 'react';
import RecordSearchContainer from 'containers/record/RecordSearchContainer';
import RecordListContainer from 'containers/record/RecordListContainer';
import RecordPaginationContainer from 'containers/record/RecordPaginationContainer';
import RecordStateContainer from 'containers/record/RecordStateContainer';
import RecordModalContainer from 'containers/modal/RecordModalContainer';


const RecordPage = () => {
    return(
        <div>
            <RecordSearchContainer/>
            <RecordStateContainer/>
            <RecordListContainer/>
            <RecordPaginationContainer/>
            <RecordModalContainer/>
        </div>
    );
}

export default RecordPage;