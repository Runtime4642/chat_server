import React from 'react';
import WorkTimeContainer from 'containers/service/WorkTimeContainer';
import WorkTimeListContainer from 'containers/service/WorkTimeListContainer';
import WorkTimePaginationContainer from 'containers/service/WorkTimePaginationContainer';
import WorkTimeModalContainer from 'containers/modal/WorkTimeModalContainer';

const WorkTimePage = () => {
    return (
        <div>
            <WorkTimeContainer/>
            <WorkTimeListContainer/>
            <WorkTimePaginationContainer/>
            <WorkTimeModalContainer/>
        </div>
    );
};

export default WorkTimePage;