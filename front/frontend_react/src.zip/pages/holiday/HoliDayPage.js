import React from 'react';
import HoliDayContainer from 'containers/service/HoliDayContainer';
import HoliDayListContainer from 'containers/service/HoliDayListContainer';
import HoliDayPaginationContainer from 'containers/service/HoliDayPaginationContainer';
import HoliDayModalContainer from 'containers/modal/HoliDayModalContainer';

const HoliDayPage = () => {
    return (
        <div>
            <HoliDayContainer/>
            <HoliDayListContainer/>
            <HoliDayPaginationContainer/>
            <HoliDayModalContainer/>
        </div>
    );
};

export default HoliDayPage;