import { createAction, handleActions } from 'redux-actions';

import { Map, List, fromJS } from 'immutable';
import { pender } from 'redux-pender';

import * as api from 'lib/api';

const INITIALIZE = 'alarm/INITIALIZE';
const ALARM_RECORD_LIST = 'alarm/ALARM_RECORD_LIST';

export const initialize = createAction(INITIALIZE);
export const getRecordTotalAlarm = createAction(ALARM_RECORD_LIST, api.getRecordTotalAlarm);

const initialState = Map({
    no: '',
    day: '',
    actor: '',
    recordType: '',
    read: '',
    tables: List(),
});

export default handleActions({
    [INITIALIZE]: (state, action) => initialState,
    ...pender({
        type: ALARM_RECORD_LIST,
        onSuccess: (state, action) => {
            console.log(action.payload);
            const { data : tables } = action.payload.data;
            return state.set('tables', fromJS(tables));
        }
    })
}, initialState);