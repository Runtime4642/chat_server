import React from 'react';
import {
  Drawer,
  IconButton,
  List,
  withStyles } from "@material-ui/core";
import {
  FilterNone as UIElementsIcon,
  BorderAll as TableIcon,
  ArrowBack as ArrowBackIcon,
} from "@material-ui/icons";
import classNames from 'classnames';

import SidebarLink from './components/SidebarLink/SidebarLinkContainer';
import locale from 'locale';

/**
* @author KJS
* @date 2019. 5. 14.
* @brief 권한에 따른 Menu
*/

const SidebarView = ({ language, auth, classes, theme, toggleSidebar, isSidebarOpened, isPermanent, location, ...props }) => {

  const userNav = [
    { id: 0, type: 'title', label: 'Commute' },
    { 
      id: 1, 
      label: locale.commuteManage[language],
      link: '/app/commute',
      icon: <UIElementsIcon />,
      children: [
        { label: locale.commuteList[language], link: '/app/commute/list' },
        { label: locale.commuteApply[language], link: '/app/commute/check'},
      ]
    },
    { id: 2, type: 'divider' },
    { id: 3, type: 'title', label: 'Working attitude' },
    { 
      id: 4, 
      label: locale.workAttitudeManage[language],
      link: '/app/workAttitude',
      icon: <UIElementsIcon />,
      children: [
        { label: locale.workAttitudeList[language], link: '/app/workAttitude/list' },
        { label: locale.workAttitudeApply[language], link: '/app/workAttitude/new' },
      ]
    },  
  ];
  
  const adminNav = [
    { id: 0, type: 'title', label: 'Commute' },
    { 
      id: 1, 
      label: locale.commuteManage[language],
      link: '/app/commute',
      icon: <UIElementsIcon />,
      children: [
        { label: locale.commuteList[language], link: '/app/commute/list' },
      ]
    },
    { id: 2, type: 'divider' },
    { id: 3, type: 'title', label: 'Working attitude' },
    { 
      id: 4, 
      label: locale.workAttitudeManage[language],
      link: '/app/workAttitude',
      icon: <UIElementsIcon />,
      children: [
        { label: locale.workAttitudeList[language], link: '/app/workAttitude/list' },
      ]
    },    
  ]
  
  const activityNav = [
    { id: 5, type: 'divider' },
    { id: 6, type: 'title', label: 'Activity' },
    { id: 7, label: locale.activeRecord[language], link: '/app/record', icon: <TableIcon /> },
  ];
  
  const serviceNav = [
    { id: 8, type: 'divider' },
    { id: 9, type: 'title', label: 'Service' },
    { 
      id: 10, 
      label: locale.serviceSetting[language],
      link: '/app/service',
      icon: <UIElementsIcon />,
      children: [
        { label: locale.workTimeSetting[language], link: '/app/service/worktime' },
        { label: locale.breakTimeSetting[language], link: '/app/service/breaktime' },
        { label: locale.holidaySetting[language], link: '/app/service/holiday' },
      ]
    },
  ];
  
  return (
    <Drawer
      variant={isPermanent ? 'permanent' : 'temporary'}
      className={classNames(classes.drawer, {
        [classes.drawerOpen]: isSidebarOpened,
        [classes.drawerClose]: !isSidebarOpened,
      })}
      classes={{
        paper: classNames({
          [classes.drawerOpen]: isSidebarOpened,
          [classes.drawerClose]: !isSidebarOpened,
        }),
      }}
      open={isSidebarOpened}
    >
      <div className={classes.toolbar} />
      <div className={classes.mobileBackButton}>
        <IconButton
          onClick={toggleSidebar}
        >
          <ArrowBackIcon classes={{ root: classNames(classes.headerIcon, classes.headerIconCollapse) }} />
        </IconButton>
      </div>
      <List className={classes.sidebarList}>
        {
          auth === "ROLE_USER" &&
          userNav.map(link => <SidebarLink key={link.id} location={location} isSidebarOpened={isSidebarOpened} {...link} />)
        }
        {
          auth === "ROLE_ADMIN" && 
          adminNav.map(link => <SidebarLink key={link.id} location={location} isSidebarOpened={isSidebarOpened} {...link} />)
        }
        {
          activityNav.map(link => <SidebarLink key={link.id} location={location} isSidebarOpened={isSidebarOpened} {...link} />)
        }
        {
          auth === "ROLE_ADMIN" &&
          serviceNav.map(link => <SidebarLink key={link.id} location={location} isSidebarOpened={isSidebarOpened} {...link} />)
        }
      </List>
    </Drawer>
  );
}

const drawerWidth = 240;

const styles = theme => ({
  menuButton: {
    marginLeft: 12,
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: 'nowrap',
  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing.unit * 7 + 40,
    [theme.breakpoints.down("sm")]: {
      width: drawerWidth,
    }
  },
  toolbar: {
    ...theme.mixins.toolbar,
    [theme.breakpoints.down("sm")]: {
      display: 'none',
    }
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing.unit * 3,
  },
  sidebarList: {
    marginTop: theme.spacing.unit * 6,
  },
  mobileBackButton: {
    marginTop: theme.spacing.unit * .5,
    marginLeft: theme.spacing.unit * 3,
    [theme.breakpoints.only("sm")]: {
      marginTop: theme.spacing.unit * .625,
    },
    [theme.breakpoints.up("md")]: {
      display: 'none',
    }
  }
});

export default withStyles(styles, { withTheme: true })(SidebarView);
