import React from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';

import themes, { overrides } from '../themes';
import Layout from './Layout/Layout';
import Error from '../pages/error/Error';
import Login from '../pages/login';
import { LocaleProvider } from 'antd';
import koKR from 'antd/lib/locale-provider/ko_KR';
import enUS from 'antd/lib/locale-provider/en_US';
import moment from 'moment';


moment.locale('en');


const theme = createMuiTheme({...themes.default, ...overrides});

const PrivateRoute = ({ isAuthenticated, component, ...rest }) => {
  return (
    <Route
      {...rest} render={props => (
        isAuthenticated ? (
        React.createElement(component, props)
      ) : (
        <Redirect
          to={{
            pathname: '/login',
            state: { from: props.location },
          }}
        />
      )
    )}
    />
  );
};

const PublicRoute = ({ isAuthenticated, component, ...rest }) => {
  return (
    <Route
      {...rest} render={props => (
        isAuthenticated ? (
        <Redirect
          to={{
            pathname: '/',
          }}
        />
      ) : !window.sessionStorage.getItem("id_token") && (
        React.createElement(component, props)
      )
    )}
    />
  );
};

const App = ({isAuthenticated}) => (
  <LocaleProvider locale={enUS}>
  <MuiThemeProvider theme={theme}>
    <BrowserRouter>
      <Switch>
        <Route exact path="/" render={() => 
          window.sessionStorage.getItem('path') ?
          <Redirect to={window.sessionStorage.getItem('path')} /> :
          <Redirect to="/app/commute/list" />} />
          
        <Route exact path="/app" render={() => 
          window.sessionStorage.getItem('path') ?
          <Redirect to={window.sessionStorage.getItem('path')} /> :
          <Redirect to="/app/commute/list" />} />

        <PrivateRoute isAuthenticated={isAuthenticated} path="/app" component={Layout} />
        <PublicRoute isAuthenticated={isAuthenticated} path="/login" component={Login} />
        <Route component={Error} />
      </Switch>
    </BrowserRouter>
  </MuiThemeProvider>
  </LocaleProvider>
);

export default App;