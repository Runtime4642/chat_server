import React, {Component} from 'react';
import {Grid} from '@material-ui/core';
import Widget from 'components/Widget';
import {PieChart, Pie, ResponsiveContainer, Sector} from "recharts";
import locale from 'locale';


class RecordState extends Component {

    render() {
        const {tables, language} = this.props;

        const normal = tables.get("읽음");
        const error = tables.get("읽지않음");

        const PieChartData = [
            {name: normal, value: normal, color: "primary"},
            {name: error, value: error, color: "success"},
        ];

        const renderActiveShape = (props) => {
            const RADIAN = Math.PI / 180;
            const {
                cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle,
                fill, payload, percent, value,
            } = props;
            const sin = Math.sin(-RADIAN * midAngle);
            const cos = Math.cos(-RADIAN * midAngle);
            const sx = cx + (outerRadius + 10) * cos;
            const sy = cy + (outerRadius + 10) * sin;
            const mx = cx + (outerRadius + 30) * cos;
            const my = cy + (outerRadius + 30) * sin;
            const ex = mx + (cos >= 0 ? 1 : -1) * 22;
            const ey = my;
            const textAnchor = cos >= 0 ? 'start' : 'end';

            return (
                <g>
                    <text x={cx} y={cy} dy={8} textAnchor="middle" fill={fill}>{payload.name}</text>
                    <Sector
                        cx={cx}
                        cy={cy}
                        innerRadius={innerRadius}
                        outerRadius={outerRadius}
                        startAngle={startAngle}
                        endAngle={endAngle}
                        fill={fill}
                    />
                </g>
            );
        };

        return (
            <React.Fragment>
                <br/>
                <Grid container spacing={32}>
                    <Grid item lg={5} md={5} sm={6} xs={12}>
                        <Widget title={locale.Read[language]} noBodyPadding upperTitle>
                            <ResponsiveContainer width="100%" height={144}>
                                <Grid container spacing={16}>
                                    <Grid item sm={6}>
                                        <div style={pieChartLegendWrapper}>
                                            <PieChart width={160} height={144} margin={0}>
                                                <Pie
                                                    activeIndex={0}
                                                    activeShape={renderActiveShape}
                                                    data={PieChartData}
                                                    innerRadius={45}
                                                    outerRadius={60}
                                                    fill={'#28a745'}
                                                    dataKey="value"
                                                />
                                            </PieChart>
                                        </div>
                                    </Grid>
                                </Grid>
                            </ResponsiveContainer>
                        </Widget>
                    </Grid>
                    <Grid item lg={5} md={4} sm={6} xs={12}>
                        <Widget title={locale.UnRead[language]} noBodyPadding upperTitle>
                            <ResponsiveContainer width="100%" height={144}>
                                <Grid container spacing={16}>
                                    <Grid item sm={6}>
                                        <div style={pieChartLegendWrapper}>
                                            <PieChart width={160} height={144} margin={0}>
                                                <Pie
                                                    activeIndex={1}
                                                    activeShape={renderActiveShape}
                                                    data={PieChartData}
                                                    innerRadius={45}
                                                    outerRadius={60}
                                                    fill={'#dc3545'}
                                                    dataKey="value"
                                                />
                                            </PieChart>
                                        </div>
                                    </Grid>
                                </Grid>
                            </ResponsiveContainer>
                        </Widget>
                    </Grid>
                </Grid>

                <br/>
            </React.Fragment>
        )
    }
}

const pieChartLegendWrapper = {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "flex-end",
}

export default RecordState;