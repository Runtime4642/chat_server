import React, {Component} from 'react';
import {Badge} from 'react-bootstrap';
import {Grid, Table, TableRow, TableHead, TableBody, TableCell} from '@material-ui/core';
import Widget from 'components/Widget';
import locale from 'locale';

class RecordList extends Component {

    handleShowModal = (table) => {
        console.log(table);
        const {handleChangeInput} = this.props;

        handleChangeInput({name: 'no', value: table.no});
        handleChangeInput({name: 'modal', value: true});
    }

    render() {
        const {tables, language} = this.props;

        console.log(tables);

        const RecordList = tables.map(
            (table, index) => {
                let {day, actor, insertUserId, recordType, recordTypeEn, content, contentEn, read} = table.toJS();
                let badge = '';

                if (read === true) {
                    badge = "success";
                } else {
                    badge = "danger";
                }

                if(language === "en"){
                    recordType = recordTypeEn;
                    content = contentEn;
                }
                else{
                    read === true? read = '읽음' : read = '읽지않음';
                }

                return (
                    <TableRow hover key={index} onClick={event => this.handleShowModal(table.toJS())}>
                        <TableCell className="pl-3 fw-normal">{day}</TableCell>
                        <TableCell id="actor">{actor}</TableCell>
                        <TableCell id="id">{insertUserId}</TableCell>
                        <TableCell>{recordType}</TableCell>
                        <TableCell>{content}</TableCell>
                        <TableCell><h6><Badge variant={badge}>{String(read)}</Badge></h6></TableCell>
                    </TableRow>
                );
            }
        );

        return (
            <React.Fragment>
                <Grid item xs={12}>
                    <Widget>
                        <div>
                            <Table className="mb-0">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>{locale.Date[language]}</TableCell>
                                        <TableCell>{locale.ActiveAgent[language]}</TableCell>
                                        <TableCell>{locale.Id[language]}</TableCell>
                                        <TableCell>{locale.Type[language]}</TableCell>
                                        <TableCell>{locale.Contents[language]}</TableCell>
                                        <TableCell>{locale.ReadCheck[language]}</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {RecordList}
                                </TableBody>
                            </Table>
                        </div>
                    </Widget>
                </Grid>
            </React.Fragment>
        );
    }
}

export default RecordList;