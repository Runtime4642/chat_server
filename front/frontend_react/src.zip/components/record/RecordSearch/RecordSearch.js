import React, {Component} from 'react';
import {Button, Row, Col} from 'react-bootstrap';
import {Button as Btn, Dropdown, Icon, Input, Menu, AutoComplete} from 'antd/lib/index';
import Modal from "react-awesome-modal";
import * as api from 'lib/api';
import locale from 'locale';

import { DatePickerInput } from 'rc-datepicker';
import 'rc-datepicker/lib/style.css';
import 'moment/locale/en-ca';
import 'moment/locale/ko';
import moment from 'moment';

const Option = AutoComplete.Option;
const OptGroup = AutoComplete.OptGroup;

let a = false;
let tableUserSelect = false;
let selectNo = 0;

class RecordSearch extends Component {

    constructor(props) {
        super(props);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        this.state = {
            yesterday,
            changeValue: "",
            arry: [],
            dataSource: [
                {
                    title: '회원리스트',
                    children: []
                }
            ],
            selectNo: "",
            select: false,
            selectName: ""
        }
        this.searchFromDateChange = this.searchFromDateChange.bind(this);
        this.searchToDateChange = this.searchToDateChange.bind(this);
    }

    // List 검색 시작 날짜 값 변경
    searchFromDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "startdate";
       onChangeInput({name, value});
    }

    // List 검색 끝 날짜 값 변경
    searchToDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "enddate";
       onChangeInput({name, value});
    }

    handleChange = (e) => {
        const {onChangeInput} = this.props;
        const {value, name} = e.target;
        onChangeInput({name, value});
    }

    handleTypeChange = (e) => {
        const {onChangeInput} = this.props;
        const name = 'newRecordType';
        const value = e.key;

        onChangeInput({name, value});
    }

    handleReadChange = (e) => {
        const {onChangeInput} = this.props;
        const name = 'newRead';
        const value = e.key;

        onChangeInput({name, value});
    }

    handleSubmit = () => {
        // const {onSubmit} = this.props;

        // onSubmit();
    }

    _onChange = (value) => {

        this.setState({
            changeValue: value
        })
        let ary = [{title: "회원리스트", children: []}];
        if (value != "") {
            this.state.arry[0].children.map((items, index) => {
                if (items.title.includes(value)) {
                    ary[0].children.push(
                        {
                            title: items.title,
                            no: items.no,
                            name: items.name
                        }
                    )
                }
            })

        }

        this.setState({
            dataSource:
            ary
        })
        if (a) {
            this.setState({
                dataSource: [
                    {
                        title: '회원리스트',
                        children: []
                    }
                ],
                selectNo: "",
                select: false,
                selectName: ""
            })
            a = false;
        }
    }

    _onChange2 =(value)=> {
        // this.setState( {
        //     dataSource : [
        //         {
        //          title: '회원리스트',
        //           children: [

        //           ]
        //         }
        //       ]})
        this.setState({
            changeValue: value
        })
        let ary = [{title: "회원리스트", children: []}];
        if (value != "") {
            this.state.arry[0].children.map((items, index) => {
                if (items.title.includes(value)) {
                    ary[0].children.push(
                        {
                            title: items.title,
                            no: items.no,
                            name: items.name
                        }
                    )
                }
            })

        }

        this.setState({
            dataSource2:
            ary
        })
        if (tableUserSelect) {
            this.setState({
                dataSource2: [
                    {
                        title: '회원리스트',
                        children: []
                    }
                ],
                selectNo: "",
                select: false,
                selectName: ""
            })
            tableUserSelect = false;
        }
    }

    componentWillMount() {
        const {token} = this.props;
        let ary = [{title: "회원리스트", children: []}];
        api.getUserListByName(token).then(response => {
            console.log(response.data.data)
            if (response.data.data != null) {
                response.data.data.map((items, index) => {
                    ary[0].children.push(
                        {
                            title: items.name + "(" + items.username + ")",
                            no: items.no,
                            name: items.name
                        }
                    );
                })
                this.setState({
                    arry:
                    ary
                })
            }
        });
    }

    _select(value, option, onSubmit) {
        const {onChangeInput} = this.props;

        a = true;
        this.setState({
            selectNo: value,
            select: true,
            selectName: option.props.children
        });

        console.log(value + "@@@@" + this.state.changeValue);

        onChangeInput({name: 'no', value: value});
        onChangeInput({name: 'select', value: true});
        onChangeInput({name: 'name', value: ''});

        onSubmit(value, true, this.state.changeValue);

        this._initialization();
    }

    _select2(value, option, onSubmit) {
        const {onChangeInput} = this.props;

        tableUserSelect = true;

        this.setState({
            selectNo: value,
            select: true,
            selectName: option.props.children
        })

        onChangeInput({name: 'no', value: value});
        onChangeInput({name: 'select', value: true});
        onSubmit(value, true, this.state.changeValue);
        selectNo = value;
        this._initialization();
    }

    _seachButtonClick(onSubmit) {
        const {onChangeInput} = this.props;

        onChangeInput({name: 'select', value: false});
        onChangeInput({name: 'name', value: this.state.changeValue});
        onChangeInput({name: 'no', value: ''});

        onSubmit(this.state.selectNo, a, this.state.changeValue);

        this._initialization();
    }

    _seachButtonClick2(onSubmit) {
        const {onChangeInput} = this.props;

        onChangeInput({name: 'userName', value: this.state.changeValue});
        onChangeInput({name: 'select', value: tableUserSelect});
        onSubmit(this.state.selectNo, tableUserSelect, this.state.changeValue);

        this._initialization();
    }

    _initialization() {
        this.setState({
            dataSource: [
                {
                    title: '회원리스트',
                    children: []
                }
            ],
            selectNo: "",
            select: false,
            selectName: ""
        })
    }

    render() {
        const {searchToDateChange, searchFromDateChange} = this;
        const {startdate, enddate, name, content, recordType, read, onSubmit, language, auth} = this.props;
        const {Search} = Input;

        const menu = (
            <Menu onClick={this.handleTypeChange}>
                <Menu.Item key="전체">{locale.All[language]}</Menu.Item>
                <Menu.Item id="goToWork" key="출근">{locale.goToWork[language]}</Menu.Item>
                <Menu.Item key="퇴근">{locale.getOffWork[language]}</Menu.Item>
                <Menu.Item key="근태">{locale.workAttitude[language]}</Menu.Item>
            </Menu>
        );

        const readMenu = (
            <Menu onClick={this.handleReadChange}>
                <Menu.Item key="전체">{locale.All[language]}</Menu.Item>
                <Menu.Item id="true" key="true">{locale.Read[language]}</Menu.Item>
                <Menu.Item key="false">{locale.UnRead[language]}</Menu.Item>
            </Menu>
        )
        if (this.state.arry == null)
            return null;

        if (auth === "ROLE_ADMIN") {
            return (
                <div>
                    <Row>
                        <Col xs lg="1">
                            {locale.ActivePeriod[language]}
                        </Col>
                        
                         {/* 시작 날짜 */}
                         <Col xs lg="2">
                            <DatePickerInput
                                title={locale.Start_date[language]}
                                selected={startdate}
                                onChange={searchFromDateChange}
                                displayFormat='YYYY-MM-DD'
                                returnFormat='YYYY-MM-DD'
                                //defaultValue={this.state.yesterday}
                                locale={language}
                                readOnly={true}
                            />
                        </Col>
                        ~
                        {/* 끝 날짜 */}
                        <Col xs lg="2">
                            <DatePickerInput
                                title={locale.End_date[language]}
                                selected={enddate}
                                onChange={searchToDateChange}
                                displayFormat='YYYY-MM-DD'
                                returnFormat='YYYY-MM-DD'
                                //defaultValue={this.state.yesterday}
                                locale={language}
                                readOnly={true}
                            />
                        </Col>

                        <Col xs lg="3">
                            <AutoComplete

                                dropdownStyle={{width: 300}}
                                size="large"
                                style={{width: '100%'}}
                                dataSource={this.state.dataSource
                                    .map(group => (
                                        <OptGroup key={"회원리스트"}>
                                            {group.children.map(opt => (
                                                <Option key={opt.no} value={opt.no}>
                                                    {opt.title}
                                                </Option>
                                            ))}
                                        </OptGroup>
                                    ))}
                                onChange={(value) => this._onChange(value)}
                                onSelect={(value, option) => this._select(value, option, onSubmit)}

                            >
                                <Search placeholder={locale.Employee_name[language]}/>

                            </AutoComplete>

                        </Col>
                        <Col>
                            <Input
                                placeholder={locale.Contents[language]}
                                title="content"
                                type="text"
                                value={content}
                                name="newContent"
                                onChange={this.handleChange}
                            />
                        </Col>
                        <Col>
                            <Button onClick={() => this._seachButtonClick(onSubmit)}
                                    theme="outline">{locale.Search[language]}</Button>
                        </Col>
                    </Row>
                    <Row style={{marginTop:'10px'}}>
                        <Col xs lg="1">
                            <label>{locale.Type[language]}</label>
                        </Col>
                        <Col>
                            <Dropdown overlay={menu}>
                                <Btn style={{marginLeft: 8}}>
                                    {recordType==='전체'?locale.All[language]:
                                 recordType==='출근'?locale.goToWork[language]:
                                 recordType==='퇴근'?locale.getOffWork[language]:
                                 recordType==='근태'?locale.workAttitude[language]:''} <Icon type="down"/>
                                </Btn>
                            </Dropdown>
                        </Col>
                    </Row>
                    <Row style={{marginTop:'10px'}}>
                        <Col xs lg="1">
                            <label>{locale.ReadCheck[language]}</label>
                        </Col>
                        <Col>
                            <Dropdown overlay={readMenu}>
                                <Btn style={{marginLeft: 8}}>
                                    {read==='전체'?locale.All[language]:
                                 read==='true'?locale.Read[language]:
                                 read==='false'?locale.UnRead[language]:''} <Icon type="down"/>
                                </Btn>
                            </Dropdown>
                        </Col>
                    </Row>
                </div>
            );
        } else {
            return (
                <div>
                    <Row>
                        <Col xs lg="1">
                            {locale.ActivePeriod[language]}
                        </Col>

                        {/* 시작 날짜 */}
                        <Col xs lg="2">
                            <DatePickerInput
                                title={locale.Start_date[language]}
                                selected={startdate}
                                onChange={searchFromDateChange}
                                displayFormat='YYYY-MM-DD'
                                returnFormat='YYYY-MM-DD'
                                //defaultValue={this.state.yesterday}
                                locale={language}
                                readOnly={true}
                            />
                        </Col>
                        ~
                        {/* 끝 날짜 */}
                        <Col xs lg="2">
                            <DatePickerInput
                                title={locale.End_date[language]}
                                selected={enddate}
                                onChange={searchToDateChange}
                                displayFormat='YYYY-MM-DD'
                                returnFormat='YYYY-MM-DD'
                                //defaultValue={this.state.yesterday}
                                locale={language}
                                readOnly={true}
                            />
                        </Col>

                        <Col>
                            <Input
                                id="userContent"
                                placeholder={locale.Contents[language]}
                                title="content"
                                type="text"
                                value={content}
                                name="newContent"
                                onChange={this.handleChange}
                            />
                        </Col>
                        <Col>
                            <Button id="btnUserSearch" onClick={() => this._seachButtonClick2(onSubmit)}
                                    theme="outline">{locale.Search[language]}</Button>
                        </Col>
                    </Row>
                    <Row style={{marginTop:'10px'}}>
                        <Col xs lg="1">
                            <label>{locale.Type[language]}</label>
                        </Col>
                        <Col>
                            <Dropdown overlay={menu}>
                                <Btn style={{marginLeft: 8}}>
                                    {recordType==='전체'?locale.All[language]:
                                 recordType==='출근'?locale.goToWork[language]:
                                 recordType==='퇴근'?locale.getOffWork[language]:
                                 recordType==='근태'?locale.workAttitude[language]:''} <Icon type="down"/>
                                </Btn>
                            </Dropdown>
                        </Col>
                    </Row>
                    <Row style={{marginTop:'10px'}}>
                        <Col xs lg="1">
                            <label>{locale.ReadCheck[language]}</label>
                        </Col>
                        <Col>
                            <Dropdown overlay={readMenu}>
                                <Btn style={{marginLeft: 8}}>
                                    {read==='전체'?locale.All[language]:
                                 read==='true'?locale.Read[language]:
                                 read==='false'?locale.UnRead[language]:''} <Icon type="down"/>
                                </Btn>
                            </Dropdown>
                        </Col>
                    </Row>
                </div>
            );
        }
    }
}

export default RecordSearch;