import React, {Component} from 'react';
import { Badge } from 'react-bootstrap';
import { Grid, Table, TableRow, TableHead, TableBody, TableCell } from '@material-ui/core';
import Widget from 'components/Widget';
import locale from 'locale';

class WorkAttitudeList extends Component {

    handleShowModal = (table) => {
        //console.log(table);
        const {handleChangeInput} = this.props;
        console.log(table.no);
        handleChangeInput({name: 'no', value: table.no});
        handleChangeInput({name: 'userNo', value: table.userNo});

        handleChangeInput({name: 'modal', value: true});
    }

    render() {
        const {tables, language} = this.props;
        const {handleShowModal} = this;
        const TableList = tables.map(
            (table, index) => {
                const { userNo, workAttitudeList, name, applicationDate, day, startDay, endDay,
                     dayEn, workAttitudeListEn, stateEn, content, contentEn, workTime, state } = table.toJS();
                let {badge, lContent, lWorkAttitudeList, lState, lDay} = '';

                if('en' === language){
                    lContent = contentEn;
                    lDay = dayEn;
                    lWorkAttitudeList = workAttitudeListEn;
                    lState = stateEn;
                }else if('ko' === language){
                    lContent = content;
                    lDay = day;
                    lWorkAttitudeList = workAttitudeList;
                    lState = state;
                }

                if(lState === locale.Normal[language]){
                    badge = 'success';
                }
                else{
                    badge= 'danger';
                }

                return (
                    <TableRow key={index} hover onClick={event => handleShowModal(table.toJS())}>
                        <TableCell id="userNo" className="pl-3 fw-normal">{userNo}</TableCell>
                        <TableCell>{lWorkAttitudeList}</TableCell>
                        <TableCell id="name">{name}</TableCell>
                        <TableCell>{applicationDate}</TableCell>
                        <TableCell>{lDay}</TableCell>
                        <TableCell>{startDay}</TableCell>
                        <TableCell>{endDay}</TableCell>
                        <TableCell>{lContent}</TableCell>
                        <TableCell>{workTime}</TableCell>
                        <TableCell><h6><Badge variant={badge}>{lState}</Badge></h6></TableCell>
                    </TableRow>
                )
            }
        );
        return (
            <React.Fragment>
                <Grid item xs={12} >
                    <Widget>
                        <div>
                            <Table className="mb-0">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>User No</TableCell>
                                        <TableCell>{locale.WorkAttitudeItem[language]}</TableCell>
                                        <TableCell>{locale.Name[language]}</TableCell>
                                        <TableCell>{locale.Apply_period[language]}</TableCell>
                                        <TableCell>{locale.Day[language]}</TableCell>
                                        <TableCell>{locale.Start_date[language]}</TableCell>
                                        <TableCell>{locale.End_date[language]}</TableCell>
                                        <TableCell>{locale.WorkAttitudeContents[language]}</TableCell>
                                        <TableCell>{locale.TotalWorkTime[language]}</TableCell>
                                        <TableCell>{locale.State[language]}</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    { TableList }
                                </TableBody>
                            </Table>
                        </div>
                    </Widget>
                </Grid>
            </React.Fragment>
        )
    }
}

export default WorkAttitudeList;