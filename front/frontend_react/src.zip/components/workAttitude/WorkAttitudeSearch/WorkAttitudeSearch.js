import React, {Component} from 'react';
import {Button, Row, Col} from 'react-bootstrap';
import * as api from 'lib/api';
import {Button as Btn, Dropdown, Icon, Input, Menu, AutoComplete} from 'antd';
import './WorkAttitudeSearch.css';
import locale from 'locale';

import { DatePickerInput } from 'rc-datepicker';
import 'rc-datepicker/lib/style.css';
import 'moment/locale/en-ca';
import 'moment/locale/ko';
import moment from 'moment';

const Option = AutoComplete.Option;
const OptGroup = AutoComplete.OptGroup;

let calendarUserSelect=false;
let tableUserSelect=false;
let selectNo=0;
let onSelect = false;
class WorkAttitudeSeacrch extends Component {

    constructor(props) {
        super(props);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        this.state = {
            yesterday,
            changeValue:"",
            sWorkAttitude: "",
            arry:[],
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              dataSource2 : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              selectNo:"",
              select:false,
              selectName:""
        }
        this.searchFromDateChange = this.searchFromDateChange.bind(this);
        this.searchToDateChange = this.searchToDateChange.bind(this);
        this.searchCalendarChange = this.searchCalendarChange.bind(this);
    }

    // List 검색 시작 날짜 값 변경
    searchFromDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "searchFromDate";
        onChangeInput({name, value});
    }

    // List 검색 끝 날짜 값 변경
    searchToDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "searchToDate";
        onChangeInput({name, value});
    }

    // Calendar 검색 날짜 값 변경
    searchCalendarChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM');
        let name = "searchFromDate";
        onChangeInput({name, value});
    }

    handleChange = (e) => {
        const {onChangeInput} = this.props;
        const {value, name} = e.target;
        onChangeInput({name, value});
    }

    handleDropdownChange = (e) => {
        const { onChangeInput } = this.props;
        const name = 'searchWorkAttitude';
        const value = e.key;
        console.log("------->> ", e.item.props.children);
        this.setState({sWorkAttitude: e.item.props.children});
        onChangeInput({name, value});
    }

    handleSubmit = () => {
        const {onChangeInput,onSubmit} = this.props;
        onSubmit(selectNo,true,this.state.changeValue);
        onChangeInput({name: 'searchUserNo', value: this.state.selectNo});
        onChangeInput({name: 'searchUserName', value: this.state.changeValue});

        this._initialization();
    }
    handleSubmit2 = () => {
        const {onChangeInput,onSubmit} = this.props;

        onSubmit(this.state.selectNo,tableUserSelect,this.state.changeValue);
        onChangeInput({name: 'searchUserNo', value: this.state.selectNo});
        onChangeInput({name: 'searchUserName', value: this.state.changeValue});

        this._initialization();
    }

    componentWillMount(){
        
        const {token} = this.props;
        let ary =[{title:"회원리스트",children:[]}];
        api.getUserListByName(token).then(response => {
            if(response.data.data != null){
            response.data.data.map((items,index)=>{
                  ary[0].children.push( 
                      {
                        title: items.name+"(" +items.username+")",
                        no:items.no,
                        name:items.name
                      }

                  );                             
            })
            this.setState({
                arry:
                    ary               
            })
        }
        });
    }
    _onChange =(value)=>{
        // this.setState( {
        //     dataSource2 : [
        //         {
        //          title: '회원리스트',
        //           children: [
                   
        //           ]
        //         }
        //       ]})
        this.setState({
            changeValue : value
        })
        let ary =[{title:"회원리스트",children:[]}];
        if(value != ""&& this.state.arry[0] != null){
           this.state.arry[0].children.map((items,index)=>{
                if(items.title.includes(value)){
                    ary[0].children.push( 
                        {
                          title: items.title,
                          no:items.no,
                          name:items.name      
                        }
                    )
                }
           })

        }

        this.setState({
            dataSource:
                ary   
        })
        if(calendarUserSelect){
        this.setState({
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
            selectNo:"",
            select:false,
            selectName:""
        })
        calendarUserSelect=false;
    }
  

    }
    _onChange2 =(value)=>{
        // this.setState( {
        //     dataSource : [
        //         {
        //          title: '회원리스트',
        //           children: [
                   
        //           ]
        //         }
        //       ]})
        this.setState({
            changeValue : value
        })
        let ary =[{title:"회원리스트",children:[]}];
        if(value != ""&& this.state.arry[0] != null){
           this.state.arry[0].children.map((items,index)=>{
                if(items.title.includes(value)){
                    ary[0].children.push( 
                        {
                          title: items.title,
                          no:items.no,
                          name:items.name      
                        }
                    )
                }
           })

        }

        this.setState({
            dataSource2:
                ary   
        })
        if(tableUserSelect){
        this.setState({
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ]
        })
        if(onSelect){
            onSelect=false;
            }
            else{
                tableUserSelect=false;
            }
    }
  

    }
    _select(value,option,onSubmit){
        calendarUserSelect=true;
        selectNo=value;
        this.setState({
            selectNo:value,
            select:true,
            selectName:option.props.children
        })
        onSubmit(value,true,this.state.changeValue);
        this._initialization();
    }

    _select2(value,option,onSubmit){
        onSelect = true;
        tableUserSelect=true;
        this.setState({
            selectNo:value,
            select:true,
            selectName:option.props.children
        })
        onSubmit(value,true,this.state.changeValue);
        this._initialization();
    }
    _initialization(){
        this.setState( {
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              dataSource2 : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ]
        })
    }

    render() {
        const { handleDropdownChange, searchToDateChange, searchFromDateChange, searchCalendarChange } = this;
        const {language, searchFromDate, searchToDate, searchWorkAttitude, onSubmit, changeView,auth} = this.props;
        const {Search} = Input;

        const menu = (
            <Menu onClick={handleDropdownChange}>
                <Menu.Item key="전체">{locale.All[language]}</Menu.Item>
                <Menu.Item key="출장">{locale.Business_trip[language]}</Menu.Item>
                <Menu.Item key="외근">{locale.Work_outside[language]}</Menu.Item>
                <Menu.Item key="연차">{locale.Annual_leave[language]}</Menu.Item>
                <Menu.Item key="반차">{locale.Semi_annual_leave[language]}</Menu.Item>
                <Menu.Item id="seminar" key="교육">{locale.Education[language]}</Menu.Item>
            </Menu>
        );
        if(auth==="ROLE_ADMIN")
        return (
            <div>
             <div className={changeView==='table'?'show':'hide'}>
                <Row key="en">
                    <Col xs lg="1">
                        {locale.Apply_period[language]}
                    </Col>

                    {/* 시작 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchFromDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
                    ~
                    {/* 끝 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.End_date[language]}
                            selected={searchToDate}
                            onChange={searchToDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>

                    <Col xs lg="3">
                    <AutoComplete
                    dropdownStyle={{ width: 300 }}
                    size="large"
                    style={{ width: '100%' }}
                    dataSource={this.state.dataSource2
                        .map(group => (
                        <OptGroup key={"회원리스트"}>
                            {group.children.map(opt => (
                            <Option key={opt.no} value={opt.no}>
                                {opt.title}
                            </Option>
                            ))}
                        </OptGroup>
                        ))}
                    onChange={(value)=>this._onChange2(value)}
                    onSelect={(value,option)=>this._select2(value,option,onSubmit)}

                    >
                    <Search placeholder={locale.Employee_name[language]} />
                    </AutoComplete>
                    </Col>
                    <Col>
                        <Button onClick={this.handleSubmit2} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <label>{locale.Division[language]}</label>
                        <Dropdown overlay={menu} >
                            <Btn style={{ marginLeft: 8 }} >
                                {searchWorkAttitude==='전체'?locale.All[language]:
                                searchWorkAttitude==='출장'?locale.Business_trip[language]:
                                searchWorkAttitude==='외근'?locale.Work_outside[language]:
                                searchWorkAttitude==='연차'?locale.Annual_leave[language]:
                                searchWorkAttitude==='반차'?locale.Semi_annual_leave[language]:
                                searchWorkAttitude==='교육'?locale.Education[language]:''} <Icon type="down" />
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>
            </div>

            <div className={changeView==='calendar'?'show':'hide'}>
                <Row>
                    <Col xs lg="1">
                        {locale.Apply_period[language]}
                    </Col>

                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchCalendarChange}
                            displayFormat='YYYY-MM'
                            returnFormat='YYYY-MM'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            startMode='month'
                            fixedMode={true}
                        />
                    </Col>

                    <Col xs lg="3">
                    <AutoComplete
                    dropdownStyle={{ width: 300 }}
                    size="large"
                    style={{ width: '100%' }}
                    dataSource={this.state.dataSource
                        .map(group => (
                        <OptGroup key={"회원리스트"}>
                            {group.children.map(opt => (
                            <Option key={opt.no} value={opt.no}>
                                {opt.title}
                            </Option>
                            ))}
                        </OptGroup>
                        ))}
                    onChange={(value)=>this._onChange(value)}
                    onSelect={(value,option)=>this._select(value,option,onSubmit)}

                    >
                    <Search placeholder={locale.Employee_name[language]} />
                    </AutoComplete>
                    </Col>
                    <Col>
                        <Button onClick={this.handleSubmit} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <label>{locale.Division[language]}</label>
                        <Dropdown overlay={menu} >
                            <Btn style={{ marginLeft: 8 }} >
                                {searchWorkAttitude==='전체'?locale.All[language]:
                                searchWorkAttitude==='출장'?locale.Business_trip[language]:
                                searchWorkAttitude==='외근'?locale.Work_outside[language]:
                                searchWorkAttitude==='연차'?locale.Annual_leave[language]:
                                searchWorkAttitude==='반차'?locale.Semi_annual_leave[language]:
                                searchWorkAttitude==='교육'?locale.Education[language]:''} <Icon type="down" />
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>
            </div>
            </div>
          );
          else
          return (
            <div>
             <div className={changeView==='table'?'show':'hide'}>
                <Row>
                    <Col xs lg="1">
                        {locale.Apply_period[language]}
                    </Col>

                    {/* 시작 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchFromDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
                    ~
                    {/* 끝 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.End_date[language]}
                            selected={searchToDate}
                            onChange={searchToDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
               
                    <Col>
                        <Button id="btnSearch" onClick={this.handleSubmit2} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <label>{locale.Division[language]}</label>
                        <Dropdown overlay={menu} >
                            <Btn style={{ marginLeft: 8 }} >
                                {searchWorkAttitude==='전체'?locale.All[language]:
                                searchWorkAttitude==='출장'?locale.Business_trip[language]:
                                searchWorkAttitude==='외근'?locale.Work_outside[language]:
                                searchWorkAttitude==='연차'?locale.Annual_leave[language]:
                                searchWorkAttitude==='반차'?locale.Semi_annual_leave[language]:
                                searchWorkAttitude==='교육'?locale.Education[language]:''} <Icon type="down" />
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>
            </div>

            <div className={changeView==='calendar'?'show':'hide'}>
                <Row>
                    <Col xs lg="1">
                        {locale.Apply_period[language]}
                    </Col>
                    
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchCalendarChange}
                            displayFormat='YYYY-MM'
                            returnFormat='YYYY-MM'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            startMode='month'
                            fixedMode={true}
                        />
                    </Col>

                    <Col>
                        <Button onClick={this.handleSubmit} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <label>{locale.Division[language]}</label>
                        <Dropdown overlay={menu} >
                            <Btn style={{ marginLeft: 8 }} >
                                {searchWorkAttitude==='전체'?locale.All[language]:
                                searchWorkAttitude==='출장'?locale.Business_trip[language]:
                                searchWorkAttitude==='외근'?locale.Work_outside[language]:
                                searchWorkAttitude==='연차'?locale.Annual_leave[language]:
                                searchWorkAttitude==='반차'?locale.Semi_annual_leave[language]:
                                searchWorkAttitude==='교육'?locale.Education[language]:''} <Icon type="down" />
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>
            </div>
            </div>
          );
    }
}

export default WorkAttitudeSeacrch;