import React, { Component } from "react";
import { Button, Row, Col, Form,Modal } from "react-bootstrap";
import { Input, message } from "antd";
import moment from "moment";
import locale from "locale";
import { DatePickerInput } from "rc-datepicker";
import "rc-datepicker/lib/style.css";
import "moment/locale/en-ca";
import "moment/locale/ko";


let lan ="";
let a = true;
class WorkAttitudeAdd extends Component {
  constructor(props) {
    super(props);
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    this.state = {
      yesterday
    };
    this.startDayChange = this.startDayChange.bind(this);
    this.endDayChange = this.endDayChange.bind(this);
  }

  // 신청 시작 날짜 값 변경
  startDayChange(date) {
    const { onChangeInput } = this.props;
    let value = moment(date).format("YYYY-MM-DD");
    let name = "startDay";
    onChangeInput({ name, value });
    a=false;
  }

  // 신청 끝 날짜 값 변경
  endDayChange(date) {
    const { onChangeInput } = this.props;
    let value = moment(date).format("YYYY-MM-DD");
    let name = "endDay";
    onChangeInput({ name, value });
    a=false;
  }

  handleChange = e => {
    const { onChangeInput,language } = this.props;
    const { value, name } = e.target;
    onChangeInput({ name, value });
    a=false;
    console.log(lan);
    if(language === "en"){
      onChangeInput({name: 'descriptionEn', value: value});
  }
  else {
      onChangeInput({name, value});
  }
  };
  ButtonCkick = (e) => {
    const { onChangeInput, language,LanActions } = this.props;
    const { value, name } = e.target;

    if(language=="ko"){
      LanActions.changeLanguage("ko");
      lan="ko"
      }
      else if(language=="en"){
      LanActions.changeLanguage("en");
      lan="en"
      }
    a=false;
}

  submitCheck = () => {
    const {
      startDay,
      endDay,
      title,
      content,
      language,
      onSubmit,
      loginName,
      onChangeInput
    } = this.props;

    if (startDay <= 0 || endDay <= 0) {
      message.info(locale.Empty_Period[language]);
      return;
    }

    if (startDay > endDay) {
      message.info(locale.Time_Longer[language]);
      return;
    }

    if (title <= 0) {
      message.info(locale.Empty_Subject[language]);
      return;
    }

    if (content <= 0) {
      message.info(locale.Empty_Present[language]);
      return;
    }

    onChangeInput({ name: "name", value: loginName });
    onSubmit();
  };

  openModal = () => {
    const { onChangeInput } = this.props;
    let name= "workAttitudeAddModal";
    let value =true;
    onChangeInput({name, value});

  };
  //취소버튼 눌렀을때
  cancelButtonClick= () => {
    const { onChangeInput,LanActions,language } = this.props;
    let name= "workAttitudeAddModal";
    let value =false;
    onChangeInput({name, value});

    if(language=="ko"){
    LanActions.changeLanguage("en");
    lan="en"
    }
    else if(language=="en"){
    LanActions.changeLanguage("ko");
    lan="ko"
    }

    a=false;
    

  };
    //확인버튼 눌렀을때
    okButtonClick= () => {
        const { onChangeInput} = this.props;
        let name= "workAttitudeAddModal";
        let value =false;
        onChangeInput({name, value});
    
        name="title";
        value="";
        onChangeInput({name, value});

        name="content";
        value="";
        onChangeInput({name, value});
    
      };



  render() {
    const { handleChange, submitCheck,okButtonClick, startDayChange, endDayChange,openModal,cancelButtonClick } = this;
    const { TextArea } = Input;

    const {
      startDay,
      endDay,
      title,
      gubun,
      content,
      loginName,
      language,
      workAttitudeAddModal
    } = this.props;

    console.log("lan")
    if(language == "ko" && lan != language && (title!="" || content !="") &&a)
    {
        openModal();
        lan = language;
        console.log(lan);
    }
    else if(language == "en" && lan != language && (title!="" || content !="")&& a)
    {
        openModal();
        lan = language;
        console.log(lan);
    }
    a=true;



    return (
      <div className="container-fluid">  
        <Row>
          <Col xs lg="1">
            {locale.Name[language]} :{" "}
          </Col>
          <Col xs lg="2">
            <Form.Control
              placeholder="홍길동"
              type="text"
              value={loginName}
              disabled={true} 
              onChange={handleChange}
              name="name"
            />
          </Col>
        </Row>

        <br />

        <Row>
          <Col xs lg="1">
            {locale.Period[language]} :{" "}
          </Col>
          {/* 시작 날짜 */}
          <Col xs lg="2">
            <DatePickerInput
              title={locale.Start_date[language]}
              value={startDay}
              selected={startDay}
              onChange={startDayChange}
              displayFormat="YYYY-MM-DD"
              returnFormat="YYYY-MM-DD"
              //defaultValue={this.state.yesterday}
              locale={language}
              readOnly={true}
            />
          </Col>
          ~{/* 끝 날짜 */}
          <Col xs lg="2">
            <DatePickerInput
              title={locale.End_date[language]}
              selected={endDay}
              value={endDay}
              onChange={endDayChange}
              displayFormat="YYYY-MM-DD"
              returnFormat="YYYY-MM-DD"
              //defaultValue={this.state.yesterday}
              locale={language}
              readOnly={true}
            />
          </Col>
        </Row>

        <br />

        <Row>
          <Col xs lg="1">
            {locale.Title[language]} :{" "}
          </Col>
          <Col xs lg="5">
            <Form.Control
              id="title"
              type="text"
              value={title}
              onChange={handleChange}
              name="title"
            />
          </Col>
        </Row>

        <br />

        <Row>
          <Col xs lg="1">
            {locale.WorkAttitudeDivide[language]} :{" "}
          </Col>
          <Col>
            <select
              id="gubun"
              name="gubun"
              type="text"
              value={gubun}
              onChange={handleChange}
            >
              <option value="출장">{locale.Business_trip[language]}</option>
              <option value="외근">{locale.Work_outside[language]}</option>
              <option value="연차">{locale.Annual_leave[language]}</option>
              <option value="오전반차">
                {locale.morningSemiAnnualLeave[language]}
              </option>
              <option value="오후반차">
                {locale.afternoonSemiAnnualLeave[language]}
              </option>
              <option id="seminar" value="교육">
                {locale.Education[language]}
              </option>
            </select>
          </Col>
        </Row>

        <br />

        <Row>
          <Col xs lg="1">
            {locale.WorkAttitudeReason[language]} :{" "}
          </Col>
          <Col>
            <TextArea
              id="content"
              name="content"
              rows={4}
              onChange={handleChange}
              value={content}
            />
          </Col>
        </Row>
        <br />
        <br />
        <Button id="btnSubmit" onClick={submitCheck} theme="outline">
          {locale.Submit[language]}
        </Button>
        <div />
        <div>
        <Modal show={workAttitudeAddModal} centered={true} size="lg">
                <Modal.Header closeButton={false} style={{backgroundColor: '#536DFE'}}>
                    <Modal.Title id="modal1" style={{color: '#ffffff'}}>
                        {locale.Detail[language]}
                    </Modal.Title>
                </Modal.Header> 
                <Modal.Body style={{fontWeight: 'bold'}}>
                {locale.Initialized[language]}
                    </Modal.Body>
                    <Modal.Footer style={{justifyContent: 'unset', display: 'unset'}}>
                    <Button variant="primary" onClick={okButtonClick} style={{width: 128}}>
                    {locale.Confirm[language]}
                    </Button>
                    <Button variant="primary" onClick={cancelButtonClick} style={{width: 128}}>
                    {locale.Cancel[language]}
                    </Button>
                    </Modal.Footer>
            </Modal>
        </div>
      </div>
    );
  }
}

export default WorkAttitudeAdd;
