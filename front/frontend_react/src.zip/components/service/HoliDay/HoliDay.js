import React, { Component } from 'react';
import { Button as Btn, Menu, Icon, Dropdown, message, Input } from 'antd';
import {Button} from 'react-bootstrap';
import locale from 'locale';

import { DatePickerInput } from 'rc-datepicker';
import moment from 'moment';
import 'rc-datepicker/lib/style.css';
import 'moment/locale/en-ca';
import 'moment/locale/ko';

class HoliDay extends Component {

    constructor(props) {
        super(props);
        this.newDayChange = this.newDayChange.bind(this);
    }

    newDayChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "newDay";
        onChangeInput({name, value});
    }

    UseChange = (e) => {
        const { onChangeInput } = this.props;
        const name = 'newUse';
        const value = e.key;
        onChangeInput({name, value});
    }

    handleChange = (e) => {
        const { onChangeInput } = this.props;
        const { value, name } = e.target;
        onChangeInput({name, value});
    }
    
    submitCheck = () => {
        const { day, description, onSubmit } = this.props;

        if(day <= 0){
            message.info('휴일날짜를 선택하세요.');
            return;
        }

        if(description <= 0){
            message.info('휴게설명에 내용이 없습니다.');
            return;
        }

        onSubmit();
    }

    render() {
        const { UseChange, handleChange, submitCheck, newDayChange } = this;
        const { TextArea } = Input;
        const { day, use, description, language } = this.props;

        const menu = (
            <Menu onClick={UseChange}>
              <Menu.Item key="true">true</Menu.Item>
              <Menu.Item key="false">false</Menu.Item>
            </Menu>
          );
        
        return (
            <div>
                <div>
                    <label>{locale.holidayDate[language]}</label>&nbsp;
                    
                    <DatePickerInput
                        title={locale.holidayDate[language]}
                        selected={day}
                        value={day}
                        onChange={newDayChange}
                        displayFormat='YYYY-MM-DD'
                        returnFormat='YYYY-MM-DD'
                        //defaultValue={this.state.yesterday}
                        locale={language}
                        readOnly={true}
                    />
                </div>

                <div>
                    <label>{locale.use[language]}</label>
                    <Dropdown overlay={menu} >
                        <Btn style={{ marginLeft: 8 }} >
                            {use} <Icon type="down" />
                        </Btn>
                    </Dropdown>
                </div>

                <div>
                    <label>{locale.holidayExplanation[language]}</label>
                    <TextArea name='newDescription' rows={4} onChange={handleChange} value={description} />
                </div>

                <Button onClick={submitCheck} theme="outline">{locale.Submit[language]}</Button>
            </div>
        );
    }
}

export default HoliDay;
