import React, {Component} from 'react';
import { Grid, Table, TableRow, TableHead, TableBody, TableCell } from '@material-ui/core';
import { Badge } from 'react-bootstrap';
import Widget from 'components/Widget';
import locale from 'locale';


class HoliDayList extends Component {

    handleShowModal = (table) => {
        console.log(table);
        const {handleChangeInput} = this.props;

        handleChangeInput({name: 'no', value: table.no});
        handleChangeInput({name: 'modal', value: true});
    }

    render() {
        const {tables, language} = this.props;

        const HoliDayList = tables.map(
            (table, index) => {
                let { day, description, descriptionEn, use } = table.toJS();
                let badge = '';

                if(use === true){
                    badge = 'success';
                }
                else {
                    badge = 'danger';
                }

                if(language === "en"){
                   description = descriptionEn;
                }
                else{
                    use === true? use = '사용' : use = '사용안함';
                }

                return (
                    <TableRow hover key={index} onClick={event => this.handleShowModal(table.toJS())}>
                        <TableCell>{day}</TableCell>
                        <TableCell>{description}</TableCell>
                        <TableCell><Badge variant={badge}>{String(use)}</Badge></TableCell>
                    </TableRow>
                )
            }
        );

        return(
            <React.Fragment>
                <Grid item xs={12} >
                    <Widget>
                        <div>
                            <Table className="mb-0">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>{locale.holidayDate[language]}</TableCell>
                                        <TableCell>{locale.holidayExplanation[language]}</TableCell>
                                        <TableCell>{locale.use[language]}</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    { HoliDayList }
                                </TableBody>
                            </Table>
                        </div>
                    </Widget>
                </Grid>
            </React.Fragment>
        );
    }
}


export default HoliDayList;