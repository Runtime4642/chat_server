import React, { Component } from 'react';
import { TimePicker, Button as Btn, Menu, Icon, Dropdown, message } from 'antd';
import {Button} from 'react-bootstrap';
import moment from 'moment';
import locale from 'locale';

class WorkTime extends Component {

    startTimeHandleChange = (time, value) => {
        const { onChangeInput } = this.props;
        const name = 'newStart';
        onChangeInput({name, value});
    }

    endTimeHandleChange = (time, value) => {
        const { onChangeInput } = this.props;
        const name = 'newEnd';
        onChangeInput({name, value});
    }

    handleChange = (e) => {
        const { onChangeInput } = this.props;
        const name = 'newUse';
        const value = e.key;
        onChangeInput({name, value});
    }
    
    submitCheck = () => {
        const { start, end, onSubmit } = this.props;
        const format = 'HH:mm';
        const between = moment.duration(moment(start, format).diff(moment(end, format))).asMinutes();
        if(between >= 0){
            message.info('시작시간과 끝시간의 간격이 없습니다.');
            return;
        }
        onSubmit();

    }

    render() {
        const { startTimeHandleChange, endTimeHandleChange, handleChange, submitCheck } = this;
        const { newStart, newEnd, newUse, language } = this.props;
        const format = 'HH:mm';

        const menu = (
            <Menu onClick={handleChange}>
              <Menu.Item key="true">true</Menu.Item>
              <Menu.Item key="false">false</Menu.Item>
            </Menu>
          );
        
        return (
            <div>
                <div>
                    <label>{locale.startTime[language]}</label>&nbsp;
                    <TimePicker
                        format={format}
                        value={moment(newStart, format)}
                        allowClear={false}
                        onChange={startTimeHandleChange}
                    />
                </div>
                <div>
                    <label>{locale.endTime[language]}</label>&nbsp;
                    <TimePicker
                        format={format}
                        value={moment(newEnd, format)}
                        allowClear={false}
                        onChange={endTimeHandleChange}
                    />
                </div>
                <div>
                    <label>{locale.use[language]}</label>
                    <Dropdown overlay={menu} >
                        <Btn style={{ marginLeft: 8 }} >
                            {newUse} <Icon type="down" />
                        </Btn>
                    </Dropdown>
                </div>
                <Button onClick={submitCheck} theme="outline">{locale.Submit[language]}</Button>
            </div>
        );
    }
}

export default WorkTime;
