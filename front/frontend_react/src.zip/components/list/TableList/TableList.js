import React, {Component} from 'react';
import {Grid, Table, TableRow, TableHead, TableBody, TableCell} from '@material-ui/core';
import Widget from 'components/Widget';
import {Badge} from 'react-bootstrap';
import locale from 'locale';

class TableList extends Component {

    handleShowModal = (table) => {
        console.log(table);
        const {handleChangeInput} = this.props;

        handleChangeInput({name: 'startNo', value: table.startNo});
        handleChangeInput({name: 'endNo', value: table.endNo});
        handleChangeInput({name: 'userNo', value:table.userNo});

        handleChangeInput({name: 'modal', value: true});
    }

    render() {
        const {tables, language} = this.props;
        const {handleShowModal} = this;

        const TableList = tables.map(
            (table, index) => {
                const {name, userNo, day, dayEn, totalWorktime, fromState, fromStateEn, toState, toStateEn, startTime, endTime} = table.toJS();
                let {fromBadge, toBadge, lDay, lFromState, lToState} = '';

                if('en' === language){
                    lDay = dayEn;
                    lFromState = fromStateEn;
                    lToState = toStateEn;
                }else if('ko' === language){
                    lDay = day;
                    lFromState = fromState;
                    lToState = toState;
                }

                if (lFromState === locale.Normal[language]) fromBadge = "success";
                else if(lFromState === locale.Lateness[language]) fromBadge = "warning";
                else if(lFromState === locale.Error[language]) fromBadge = "danger";
                else if(lFromState === locale.Non_enregistrement[language]) fromBadge = "primary";

                if(lToState === locale.Normal[language]) toBadge = "success";
                else if(lToState === locale.Early_leave[language]) toBadge = "secondary";
                else if(lToState === locale.Error[language]) toBadge = "danger";
                else if(lToState === locale.Non_enregistrement[language]) toBadge = "primary";

                return (
                    <TableRow hover key={index} onClick={event => handleShowModal(table.toJS())}>
                        <TableCell id="userNo" className="pl-3 fw-normal">{userNo}</TableCell>
                        <TableCell id="name">{name}</TableCell>
                        <TableCell>{lDay}</TableCell>
                        <TableCell>{startTime}</TableCell>
                        <TableCell>{endTime}</TableCell>
                        <TableCell>{totalWorktime}</TableCell>
                        <TableCell><Badge variant={fromBadge}>{lFromState}</Badge> <Badge variant={toBadge}>{lToState}</Badge></TableCell>
                    </TableRow>
                )
            }
        );
        return (
            <React.Fragment>
                <Grid item xs={12}>
                    <Widget>
                        <div>
                            <Table className="mb-0">
                                <TableHead>
                                    <TableRow>
                                        <TableCell>User No</TableCell>
                                        <TableCell>{locale.Name[language]}</TableCell>
                                        <TableCell>{locale.Day[language]}</TableCell>
                                        <TableCell>{locale.CheckInTime[language]}</TableCell>
                                        <TableCell>{locale.CheckOutTime[language]}</TableCell>
                                        <TableCell>{locale.TotalWorkTime[language]}</TableCell>
                                        <TableCell>{locale.State[language]}</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {TableList}
                                </TableBody>
                            </Table>
                        </div>
                    </Widget>
                </Grid>
            </React.Fragment>
        )
    }
}

export default TableList;