import React, {Component} from 'react';
import {Button, Row, Col, Form} from 'react-bootstrap';
import * as api from 'lib/api';
import {LocaleProvider, Button as Btn, Dropdown, Icon, Menu, Input,AutoComplete} from "antd";
import './Search.css';
import locale from 'locale';

import { DatePickerInput } from 'rc-datepicker';
import 'rc-datepicker/lib/style.css';
import 'moment/locale/en-ca';
import 'moment/locale/ko';
import moment from 'moment';

const Option = AutoComplete.Option;
const OptGroup = AutoComplete.OptGroup;

let calendarUserSelect=false;
let tableUserSelect=false;
let selectNo=0;
let onSelect = false;

class Search extends Component {

    constructor(props) {
        super(props);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        this.state = {
            yesterday,
            changeValue:"",
            arry:[],
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              dataSource2 : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              selectNo:"",
              select:false,
              selectName:""
        };
        this.searchFromDateChange = this.searchFromDateChange.bind(this);
        this.searchToDateChange = this.searchToDateChange.bind(this);
        this.searchCalendarChange = this.searchCalendarChange.bind(this);
    }

    // List 검색 시작 날짜 값 변경
    searchFromDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "searchFromDate";
       onChangeInput({name, value});
    }

    // List 검색 끝 날짜 값 변경
    searchToDateChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM-DD');
        let name = "searchToDate";
       onChangeInput({name, value});
    }

    // Calendar 검색 날짜 값 변경
    searchCalendarChange(date) {
        const { onChangeInput } = this.props;
        let value = moment(date).format('YYYY-MM');
        let name = "searchFromDate";
       onChangeInput({name, value});
    }

    selectSearch(onsubmit) {
        // onsubmit();
        this.closeModal();
    }

    handleChange = (e) => {
        const {onChangeInput} = this.props;
        const {value, name} = e.target;
        onChangeInput({name, value});
    }

    handleDropdownChange = (e) => {
        const { onChangeInput } = this.props;
        const name = 'searchState';
        const value = e.key;
        onChangeInput({name, value});
    }

    _onChange = (value)=>{

              this.setState({
                changeValue : value
            })
        let ary =[{title:"회원리스트",children:[]}];
        if(value != "" && this.state.arry[0] != null){
           this.state.arry[0].children.map((items,index)=>{
                if(items.title.includes(value)){
                    ary[0].children.push( 
                        {
                          title: items.title,
                          no:items.no,
                          name:items.name
                        }
                    )
                }
           })

        }

        this.setState({
            dataSource:
                ary   
        })
        if(calendarUserSelect){
        this.setState({
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
            selectNo:"",
            select:false,
            selectName:""
        })
        calendarUserSelect=false;
        this.setState({
            select:false
        })
    }
  

    }
    _onChange2 =(value)=>{
              this.setState({
                changeValue : value
            })
        let ary =[{title:"회원리스트",children:[]}];
        if(value != "" && this.state.arry[0] != null){
           this.state.arry[0].children.map((items,index)=>{
                if(items.title.includes(value)){
                    ary[0].children.push( 
                        {
                          title: items.title,
                          no:items.no,
                          name:items.name
                        }
                    )
                }
           })

        }

        this.setState({
            dataSource2:
                ary   
        })
        if(tableUserSelect){
        this.setState({
            dataSource2 : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ]
        })
        if(onSelect){
        onSelect=false;
        }
        else{
            tableUserSelect=false;
        }
    }


    }

    componentWillMount(){
        
        const {token} = this.props;
        let ary =[{title:"회원리스트",children:[]}];
        api.getUserListByName(token).then(response => {
            if(response.data.data != null){
            response.data.data.map((items,index)=>{
                  ary[0].children.push( 
                      {
                        title: items.name+"(" +items.username+")",
                        no:items.no,
                        name:items.name
                      }

                  );                             
            })
            this.setState({
                arry:
                    ary               
            })
        }
        });
    }
    _select(value,option,onSubmit){
        const {onChangeInput} = this.props;

        calendarUserSelect=true;
        this.setState({
            selectNo:value,
            select:true,
            selectName:option.props.children
        })

        onChangeInput({name: 'no', value: value});
        onChangeInput({name: 'select', value: true});
        onSubmit(value,true,this.state.changeValue);
        this._initialization();
    }
    _select2(value,option,onSubmit){
        onSelect=true;
        const {onChangeInput} = this.props;

        tableUserSelect=true;

        this.setState({
            selectNo:value,
            select:true,
            selectName:option.props.children
        })

        onChangeInput({name: 'no', value: value});
        onChangeInput({name: 'select', value: true});
        onSubmit(value,true,this.state.changeValue);
        this._initialization();
    }
    _seachButtonClick(onSubmit){
        const {onChangeInput} = this.props;
        onChangeInput({name: 'userName', value: this.state.changeValue});
        onChangeInput({name: 'select', value: calendarUserSelect});
        onSubmit(selectNo,true,this.state.changeValue);

        this._initialization();
    }
    _seachButtonClick2(onSubmit){
        const {onChangeInput} = this.props;

        onChangeInput({name: 'userName', value: this.state.changeValue});
        onChangeInput({name: 'select', value: tableUserSelect});
        onSubmit(this.state.selectNo,tableUserSelect,this.state.changeValue);

        this._initialization();
    }
    _initialization(){
        this.setState( {
            dataSource : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ],
              dataSource2 : [
                {
                 title: '회원리스트',
                  children: [
                   
                  ]
                }
              ]
            //   selectNo:"",
            //   select:false,
            //   selectName:""
        })
    }
    resetState = () => this.setState({ value: null })


    render() {
        const {handleChange, handleDropdownChange, searchToDateChange, searchFromDateChange, searchCalendarChange} = this;
        const { Search } = Input;
        const {searchFromDate, searchToDate, searchUserName, onSubmit, show, searchState, onClick, changeView,auth, language} = this.props;
       
        
        
        const menu = (
            <Menu onClick={handleDropdownChange}>
                <Menu.Item key="전체">{locale.All[language]}</Menu.Item>
                <Menu.Item key="정상">{locale.Normal[language]}</Menu.Item>
                <Menu.Item key="지각">{locale.Lateness[language]}</Menu.Item>
                <Menu.Item key="조퇴">{locale.Early_leave[language]}</Menu.Item>
                <Menu.Item key="에러">{locale.Error[language]}</Menu.Item>
            </Menu>
        );
        if(this.state.arry ==null)
        return null;
       
        if(auth=="ROLE_ADMIN")
            return (
                <div>
                    <div className={changeView==='calendar'?'show':'hide'}>
                <Row>
                    <Col xs lg="1">
                        {locale.CommutePeriod[language]}
                    </Col>
                    
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchCalendarChange}
                            displayFormat='YYYY-MM'
                            returnFormat='YYYY-MM'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            startMode='month'
                            fixedMode={true}
                        />
                    </Col>

                    <Col xs lg="3">
                        <AutoComplete

                        dropdownStyle={{ width: 300 }}
                        size="large"
                        style={{ width: '100%' }}
                        dataSource={this.state.dataSource
                            .map(group => (
                            <OptGroup key={"회원리스트"}>
                                {group.children.map(opt => (
                                <Option key={opt.no} value={opt.no}>
                                    {opt.title}
                                </Option>
                                ))}
                            </OptGroup>
                            ))}
                        onChange={(value)=>this._onChange(value)}
                        onSelect={(value,option)=>this._select(value,option,onSubmit)}

                        >
                        <Search placeholder={locale.Employee_name[language]} />
                        
                        </AutoComplete>
                    </Col>
                    <Col>
                        <Button onClick={() => this._seachButtonClick(onSubmit)} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>

                <Row>
                    <Col xs lg="1">
                        {locale.WorkState[language]}
                    </Col>
                    <Col>
                        <Dropdown overlay={menu}>
                            <Btn style={{marginLeft: 8}}>
                                {searchState==='전체'?locale.All[language]:
                                 searchState==='정상'?locale.Normal[language]:
                                 searchState==='지각'?locale.Lateness[language]:
                                 searchState==='조퇴'?locale.Early_leave[language]:
                                 searchState==='에러'?locale.Error[language]:''} <Icon type="down"/>
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>

            </div>
          {/* //  );
      //  }
      //  else{
       // return ( */}
            <div className={changeView==='calendar'?'hide':'show'}>
                <Row>
                    <Col xs lg="1">
                        {locale.CommutePeriod[language]}
                    </Col>

                    {/* 시작 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchFromDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
                    ~
                    {/* 끝 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.End_date[language]}
                            selected={searchToDate}
                            onChange={searchToDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
                    
                    <Col xs lg="3">
                        <AutoComplete

                        dropdownStyle={{ width: 300 }}
                        size="large"
                        style={{ width: '100%' }}
                        dataSource={this.state.dataSource2
                            .map(group => (
                            <OptGroup key={"회원리스트"}>
                                {group.children.map(opt => (
                                <Option key={opt.no} value={opt.no}>
                                    {opt.title}
                                </Option>
                                ))}
                            </OptGroup>
                            ))}
                        onChange={(value)=>this._onChange2(value)}
                        onSelect={(value,option)=>this._select2(value,option,onSubmit)}
                        >
                        <Search placeholder={locale.Employee_name[language]}/>

                        </AutoComplete>
                    </Col>
                    <Col>
                        <Button onClick={() => this._seachButtonClick2(onSubmit)} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col xs lg="1">
                        {locale.WorkState[language]}
                    </Col>
                    <Col>
                        <Dropdown overlay={menu}>
                            <Btn style={{marginLeft: 8}}>
                                {searchState==='전체'?locale.All[language]:
                                 searchState==='정상'?locale.Normal[language]:
                                 searchState==='지각'?locale.Lateness[language]:
                                 searchState==='조퇴'?locale.Early_leave[language]:
                                 searchState==='에러'?locale.Error[language]:''} <Icon type="down"/>
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>

            </div>
            </div>
        //);}
            );
        else{
            return (
                <div>
                    <div className={changeView==='calendar'?'show':'hide'}>
                <Row>
                    <Col xs lg="1">
                        {locale.CommutePeriod[language]}
                    </Col>

                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchCalendarChange}
                            displayFormat='YYYY-MM'
                            returnFormat='YYYY-MM'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            startMode='month'
                            fixedMode={true}
                        />
                    </Col>

                    <Col>
                        <Button onClick={() => this._seachButtonClick2(onSubmit)} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                 
                </Row>

                <Row>
                    <Col xs lg="1">
                        {locale.WorkState[language]}
                    </Col>
                    <Col>
                        <Dropdown overlay={menu}>
                            <Btn style={{marginLeft: 8}}>
                                {searchState==='전체'?locale.All[language]:
                                 searchState==='정상'?locale.Normal[language]:
                                 searchState==='지각'?locale.Lateness[language]:
                                 searchState==='조퇴'?locale.Early_leave[language]:
                                 searchState==='에러'?locale.Error[language]:''} <Icon type="down"/>
                            </Btn>
                        </Dropdown>
                    </Col>
                </Row>


            </div>
          {/* //  );
      //  }
      //  else{
       // return ( */}
            <div className={changeView==='calendar'?'hide':'show'}>
                <Row>
                    <Col xs lg="1">
                        {locale.CommutePeriod[language]}
                    </Col>

                    {/* 시작 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.Start_date[language]}
                            selected={searchFromDate}
                            onChange={searchFromDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>
                    ~
                    {/* 끝 날짜 */}
                    <Col xs lg="2">
                        <DatePickerInput
                            title={locale.End_date[language]}
                            selected={searchToDate}
                            onChange={searchToDateChange}
                            displayFormat='YYYY-MM-DD'
                            returnFormat='YYYY-MM-DD'
                            //defaultValue={this.state.yesterday}
                            locale={language}
                            readOnly={true}
                        />
                    </Col>

                    <Col>
                        <Button onClick={() => this._seachButtonClick2(onSubmit)} theme="outline">{locale.Search[language]}</Button>
                    </Col>
                </Row>
                <Row>
                    <Col xs lg="1">
                        {locale.WorkState[language]}
                    </Col>
                    <Col>
                        <Dropdown overlay={menu}>
                            <Btn style={{marginLeft: 8}}>
                                {searchState==='전체'?locale.All[language]:
                                 searchState==='정상'?locale.Normal[language]:
                                 searchState==='지각'?locale.Lateness[language]:
                                 searchState==='조퇴'?locale.Early_leave[language]:
                                 searchState==='에러'?locale.Error[language]:''} <Icon type="down"/>
                            </Btn>
                        </Dropdown>
                    </Col>
                    
                </Row>

            </div>
            </div>
        //);}
            );

        }

    }



}

export default Search;