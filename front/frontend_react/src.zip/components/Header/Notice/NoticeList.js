import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { noticeupdateRead } from "./NoticeListState";
import { CircularProgress } from "@material-ui/core";
import locale from 'locale';

class NoticeList extends Component {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }

    // 클릭 시 현재 데이터 storage에 저장
    handleClick(e, keyNo, day, actor, recordType) {
        const { noticeupdateRead, token, auth } = this.props;
        if(sessionStorage.getItem("keyNo")){
            sessionStorage.removeItem("keyNo", keyNo);
            if(!sessionStorage.getItem("keyNo"))
            {
                sessionStorage.setItem("keyNo", keyNo);
                noticeupdateRead(keyNo, auth, recordType, token);
            }
        }
    }

   render() {
    const { tables, isInit, isLoading, language } = this.props;
    const Notice = tables.map(
        (table, index) => {
            const{ keyNo, day, actor, content, contentEn, recordType } = table.toJS();
            
            return (
                <NavLink 
                    onClick={(e) => {this.handleClick(e, keyNo, day, actor, recordType)}}
                    to={
                        (recordType.includes("근태 신청") || recordType.includes("근태 수정")) ?
                        "/app/workAttitude" : recordType.includes("출퇴근 수정") &&
                        "/app/commute"
                        } 
                    key={index}>
                    <div key={index}>
                        {day} {language === "en" ? contentEn : content}
                        <p/>
                    </div>
                </NavLink>
            );
        }
    );
        return (
            <ul>
                {
                    //통신중이며 store 값이 초기화되지 않았으면, 로딩바생성
                    (isInit === false && isLoading === true) ? 
                    <CircularProgress size={26} /> :
                        //통신 성공했으며, 값이 초기화되면, 알람리스트 개수 비교
                        sessionStorage.getItem("alarmnum") !== tables.size &&
                            //알림리스트 개수가 변경되지 않았을 경우 
                            sessionStorage.getItem("alarmnum") !== '0' ?
                                //알림 리스트 개수가 0이 아니면 알림 list 출력
                                Notice :
                                // 알림 리스트 개수가 0이면 아래 text 출력
                                <div>{locale.alarmList[language]}</div>
                    
                }
            </ul>
        );
    }
}

export default connect(
    state => ({
        isInit: state.notice.isInit,
        isLoading: state.notice.isLoading,
        tables: state.notice.tables,
        error: state.notice.error,
        token: state.login.token,
        isReading: state.notice.isReading,
        language: state.language.language,
        auth: state.login.auth
    }),
    { noticeupdateRead }
)(NoticeList);