import React, { Component } from "react";
import { connect } from "react-redux";
import moment from "moment";
import * as commuteActions from "store/modules/commute";
import * as headerActions from "store/modules/Header";
import * as timeActions from "store/modules/time";
import { bindActionCreators } from "redux";

let timer = null;
class TimeList extends Component {
  state = {
    timeset: " "
  };
  getTime = () => {
    const hour = moment().format("HH");
    const minute = moment().format("mm");
    const second = moment().format("ss");
    const timeset = `${hour > 9 ? hour : `0${hour}`}:${minute > 9 ? minute : `0${minute}`}:${second > 9 ? second : `0${second}`}`;
    this.setState({
      timeset
    }); 
  };

  componentWillMount(){
    let cnt=0; 
    const{auth,CommuteActions,token,loginUserNo}=this.props;
    if(auth ==='ROLE_USER'){
    timer = setInterval(()=>{
      const{TimeActions,endtime,starttime,goto,gooff}=this.props;
      //console.log(goto);
      cnt++; 
      if(starttime==="" && goto){
      TimeActions.getStartTime(loginUserNo, token);  
    }
    //console.log(gooff);
      if(starttime!=="" && endtime==="" && gooff){
          TimeActions.getTotalWorkTime(loginUserNo, token);
          TimeActions.getTodayCommuteEndTime(loginUserNo,token);
        //console.log(cnt);
        clearInterval(timer);
      }
    CommuteActions.changeInput({name:'cnt', value:cnt});
    },1000);
  }
}
  render() {
    let now = moment().format('HH:mm:ss');
    const { totalWorkTime,starttime,time1,endtime} = this.props;
    let timeset;
    if(starttime === "" ){
      timeset = '00:00:00';
    }
    else if(starttime !==""){

    const selectstarttime = moment(time1, "HH:mm:ss");
    const pushstarttime = moment(starttime,  "HH:mm:ss");
    const timediff = selectstarttime.diff(pushstarttime, "seconds"); //시간

      if (timediff>0) {
        timeset="00:00:00";
      } else {
        
        const startdt = moment(now, "HH:mm:ss");
        const enddt = moment(starttime,  "HH:mm:ss");
        const secondsDiff = startdt.diff(enddt, "seconds");

        const latehour = Math.floor(secondsDiff/3600)
        const latemin = Math.floor((secondsDiff-(latehour*3600))/60)
        const latesec = (secondsDiff-(latehour*3600)-(latemin*60))

        if(latehour<0){
          timeset ="00:00:00"
        }
        else
        timeset = `${latehour > 9 ? latehour : `0${latehour}`}:${latemin > 9 ? latemin : `0${latemin}`}:${latesec > 9 ? latesec : `0${latesec}`}`;

    }

  }
  if(endtime === "")
  return <div>{timeset}</div>;
  else 
  return <div>{totalWorkTime}</div>;
  }
}

export default connect(
  state => ({
      loginUserNo:state.login.no,
      token: state.login.token,
      auth: state.login.auth,
    no: state.list.get("no"),

    lasttime: state.commute.get("lasttime"),
    cnt : state.commute.get('cnt'),
    preGoTo: state.commute.get("preGoTo"),
    goto : state.commute.get("goto"),
    gooff : state.commute.get("gooff"),
    totalWorkTime : state.time.get("totalWorkTime"),
    starttime: state.time.get("starttime"),
    time: state.time.get("time"),
    start : state.time.get("start"),
    end : state.time.get("end"),
    time1: state.time.get("time1"),
    endtime:state.time.get("endtime"),
  }),
  dispatch => ({
    CommuteActions: bindActionCreators(commuteActions, dispatch),
    HeaderActions: bindActionCreators(headerActions, dispatch),
    TimeActions: bindActionCreators(timeActions, dispatch)

  })
)(TimeList);