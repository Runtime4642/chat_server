import { compose, lifecycle } from 'recompose';
import { connect } from 'react-redux';
import { getUser } from 'pages/login/LoginState';
import { changeLanguage } from 'store/modules/language';

import AppView from './App';

export default compose(
  connect(
    state => ({
      isAuthenticated: state.login.isAuthenticated,
      language: state.language.language,
      init: state.language.init
    }),
    { getUser, changeLanguage }
  ),
  lifecycle({
    componentDidMount() {
      if(sessionStorage.getItem("language") === null) {
        sessionStorage.setItem("language", "ko");
      }

      // storage의 language와 store의 language가 다를 경우(새로 고침했을 경우)
      if(this.props.language !== sessionStorage.getItem("language") &&
          sessionStorage.getItem("language") !== null &&
          this.props.init === false) {
            this.props.changeLanguage(sessionStorage.getItem("language"));

      }

      // 새로고침했을 경우 storage에 저장된 토큰을 이용해 다시 유저 정보 요청
      if(sessionStorage.getItem("id_token") &&
          this.props.isAuthenticated === false) {
        this.props.getUser(sessionStorage.getItem("id_token"));
      }
    }
  })
)(AppView);