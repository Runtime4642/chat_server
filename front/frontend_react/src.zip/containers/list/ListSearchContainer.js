import React, {Component} from 'react';
import Search from 'components/list/Search';
import CalendarTableSelect from 'components/list/CalendarTableSelect';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import * as listActions from 'store/modules/list';
import * as getCalList from 'store/modules/commutecalendarlist';
import * as paginationList from 'store/modules/pagination';
import * as stateActions from 'store/modules/state';


class ListSearchContainer extends Component {

    handleClick = (value) => {
        const {ListActions} = this.props;
        ListActions.click(value);
    }

    handleChangeInput = ({name, value}) => {
        const {ListActions} = this.props;
        ListActions.changeInput({name, value});
    }

    handleChangeRadio = ({name, value}) => {
        const {ListActions, StateActions} = this.props;
        ListActions.changeInput({name, value});

        if (value === 'calendar') {
            StateActions.changeInput({name: 'changeView', value: 'calendar'});
        }

        if (value === 'table') {
            StateActions.changeInput({name: 'changeView', value: 'table'});
        }
    }

    handleSubmit = async (searchUserNo = 0, select, userName) => {

        const {searchFromDate, searchToDate, name, activePage, ListActions, GetCalList, PaginationActions, searchState, changeView, StateActions} = this.props;
        const {token, auth, loginUserNo, language} = this.props;

        console.log("@@@@@@")
        console.log(searchUserNo)
        console.log(select)
        console.log(userName);
        console.log("@@@@@@")
        if (auth === "ROLE_USER") {
            select = true;
            searchUserNo = loginUserNo
        }
        const search = {
            searchFromDate,
            searchToDate,
            userName,
            searchUserNo,
            searchState,
            select
        }
        const pageNumber = 1

        PaginationActions.pageChange({activePage, pageNumber});


        try {
            if (changeView === "table") {
                await StateActions.getCommuteSearchStateList(search, token);
                await PaginationActions.getSearchPage(search, token);
                await ListActions.getTableList(search, pageNumber, select, token, language);
            } else {
                if (search.searchUserNo == null)
                    search.searchUserNo = 0;

                if (!select)
                    search.searchUserNo = userName;

                await StateActions.getCommuteCalendarStateList(searchFromDate, searchUserNo, userName, searchState, select, token);
                await GetCalList.getList(search, token, select);
                GetCalList.changeInput({
                    name: "search",
                    value: search
                })
                GetCalList.changeInput({
                    name: "select",
                    value: select
                })
                GetCalList.changeInput({
                    name: "userName",
                    value: userName
                })
            }


        } catch
            (e) {
            console.log(e);
        }
    }

    componentDidMount() {
        const {ListActions} = this.props;

        ListActions.initialize();
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextProps.select !== this.props.select) {
            this.handleChangeInput({name: 'select', value: nextProps.select});
        }

        if (nextProps.username !== this.props.userName) {
            this.handleChangeInput(({name: 'userName', value: nextProps.userName}));
        }

        if (nextProps.no !== this.props.no) {
            this.handleChangeInput({name: 'no', value: nextProps.no});
        }

        return true;
    }

    render() {
        const {searchFromDate, searchToDate, name, searchUserNo, show, searchState, changeView, token, language, auth} = this.props;
        const {handleChangeInput, handleSubmit, handleChangeRadio} = this;

        return (
            <div>
                <Search
                    searchFromDate={searchFromDate}
                    searchToDate={searchToDate}
                    name={name}
                    onChangeInput={handleChangeInput}
                    onSubmit={handleSubmit}
                    onClick={this.handleClick}
                    searchUserNo={searchUserNo}
                    show={show}
                    searchState={searchState}
                    changeView={changeView}
                    token={token}
                    auth={auth}
                    language={language}
                />
                <CalendarTableSelect language={language} onChangeInput={handleChangeRadio} changeView={changeView}/>
            </div>
        );
    }
}

//구독
export default connect(
    (state) => ({
        searchFromDate: state.list.get('searchFromDate'),
        searchToDate: state.list.get('searchToDate'),
        searchState: state.list.get('searchState'),
        searchUserNo: state.list.get('searchUserNo'),
        startdate: state.list.get('startdate'),
        enddate: state.list.get('enddate'),
        name: state.list.get('name'),
        no: state.list.get('no'),
        userName: state.list.get('userName'),
        select: state.list.get('select'),
        state: state.list.get('state'),
        changeView: state.list.get('changeView'),
        activePage: state.pagination.get('activePage'),
        token: state.login.token,
        language: state.language.language,
        auth: state.login.auth,
        loginUserNo: state.login.no
    }),
    (dispatch) => ({
        ListActions: bindActionCreators(listActions, dispatch),
        GetCalList: bindActionCreators(getCalList, dispatch),
        PaginationActions: bindActionCreators(paginationList, dispatch),
        StateActions: bindActionCreators(stateActions, dispatch)
    })
)
(ListSearchContainer);