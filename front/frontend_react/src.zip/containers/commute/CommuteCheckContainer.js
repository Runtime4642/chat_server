import React, { Component } from 'react';
import Check from 'components/commute/Check';
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import * as commuteActions from 'store/modules/commute';
import * as timeActions from "store/modules/commute";
import moment from 'moment';
import locale from 'locale';

class CommuteCheckContainer extends Component {

    handleGoTo = async(preGoTo) => {
        const { CommuteActions } = this.props;
        const { token } = this.props;
        
        try{
            if(preGoTo) {
                await CommuteActions.goTo('출근', '출근 입력', token);
                
            }
            else{
                await CommuteActions.getPreGoTo('출근', '출근 입력', token);
            }
        } catch(e){
            console.log(e);
        }
    }

    handleGoOff = async(preGoOff) => {
        const { CommuteActions,TimeActions } = this.props;
        const { token,loginUserNo } = this.props;

        try{
            if(preGoOff) {
                await CommuteActions.goOff('퇴근', '퇴근 입력', token);
                
            }
            else{
                await CommuteActions.getPreGoOff('퇴근', '퇴근 입력', token);
            }
        } catch(e){
            console.log(e);
        }
    }

    handleState = async(preGoTo, preGoOff) => {
        const {token, CommuteActions} = this.props;

        try{
            await CommuteActions.getPreGoOffData(token);
            await CommuteActions.getPreGoToData(preGoTo, token);

            await CommuteActions.getGoToData(true, token);
            await CommuteActions.getGoOffData(true, token);
        }
        catch(e){
            console.log(e);
        }
    }

    handleEndTime = async() => {
        const {CommuteActions, token} = this.props;

        try{
            await CommuteActions.getEndTime(token);
        }
        catch(e){
            console.log(e);
        }
    }

    convertState(name, value){
        const { CommuteActions } = this.props;

        CommuteActions.stateChange({name, value});
    }

    componentDidMount() {
        const {endTime, language} = this.props;
        document.title = locale.commuteCheckTitle[language];

        const {CommuteActions} = this.props;
        let cnt =0;
        this.timerID = setInterval(() => {
            cnt++;
            CommuteActions.changeInput({name:'cnt', value:cnt});
            this.tick();
        }, 1000);
    }

    tick = () => {
        const {endTime, preGoTo, preGoOff,language} = this.props;
        
        this.convertState('time', new Date());

        const now = moment(new Date().getFullYear() + '-' + (new Date().getMonth()+1) + '-' + (new Date().getDate()) + " " + new Date().getHours() + ":" + new Date().getMinutes() + ":" + new Date().getSeconds(), 'YYYY-MM-DD HH:mm:ss');
        const end = moment(new Date().getFullYear() + '-' + (new Date().getMonth()+1) + '-' + (new Date().getDate()) + " " + endTime, 'YYYY-MM-DD HH:mm:ss');
        const night = moment(new Date().getFullYear() + '-' + (new Date().getMonth()+1) + '-' + (new Date().getDate()+1) + " " + "00:00:00" , 'YYYY-MM-DD HH:mm:ss')
        // console.log(now);
        // console.log(end);
        // console.log(night);
        // console.log(endTime);

        if(!preGoTo && preGoOff){
            this.convertState('preGoTo', true);
        }

        if(now.isoWeekday() === 1){
            this.convertState('preGoTo', true);
            this.convertState('preGoOff', true);
        }

        if(now.isSame(night)){
            //console.log("same");
            this.convertState('isNight', true);
        }

        if(now.isAfter(end)){
            //console.log("after");
            this.convertState('isGoOff', true);
            this.convertState('isNigiht', false);
        }

        if(now.isBefore(end)) {
            //console.log("before");
            this.convertState('isGoOff', false);
            this.convertState("isNight", false);
        }
    }

    componentWillUnmount() {
        clearInterval(this.timerID);
    }

    shouldComponentUpdate(nextProps, nextState) {
        document.title = locale.commuteCheckTitle[nextProps.language];
        
        if(nextProps.endTime !== this.props.endTime){
            this.convertState('endTime', nextProps.endTime);
        }

        if(nextProps.isGoOff !== this.props.isGoOff){
            this.convertState('isGoOff', nextProps.isGoOff);
        }

        return true;
    }

    componentWillMount() {
        if(window.sessionStorage.getItem("path")) {
            window.sessionStorage.removeItem("path");
        }
        window.sessionStorage.setItem("path", "/app/commute/check");

        this.handleState(this.props.preGoTo, this.props.preGoOff);
        this.handleEndTime();
    }

    render(){
        const { language,goto, gooff, isGoOff, loading, endTime, visible, time, isNight, preGoTo, preGoOff} = this.props;

        if(loading) return null;

        return(
            <div>
                <Check language = {language} isNight={isNight} time={time} visible={visible} endTime={endTime} isGoOff={isGoOff} goto={goto} gooff={gooff} preGoTo={preGoTo} preGoOff={preGoOff}
                       onGoTo={this.handleGoTo} onGoOff={this.handleGoOff} onChangeInput={this.convertState.bind(this)} onHandleState={this.handleState}/>
            </div>
        );
    }
}

export default connect(
    (state) => ({
        loginUserNo:state.login.no,
        goto: state.commute.get("goto"),
        gooff: state.commute.get("gooff"),
        preGoTo: state.commute.get("preGoTo"),
        preGoOff: state.commute.get("preGoOff"),
        no: state.list.get('no'),
        isGoOff: state.commute.get('isGoOff'),
        isNight: state.commute.get('isNight'),
        endTime: state.commute.get('endTime'),
        time: state.commute.get('time'),
        cnt : state.commute.get('cnt'),
        loading: state.pender.pending['commute/GET_END_TIME'],
        token: state.login.token,
        language: state.language.language
    }),
    (dispatch) => ({
        CommuteActions: bindActionCreators(commuteActions, dispatch),
        TimeActions: bindActionCreators(timeActions, dispatch)
    })
)(CommuteCheckContainer);