import React, { Component } from 'react';
import RecordState from 'components/record/RecordState';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as stateActions from 'store/modules/state';

class RecordStateContainer extends Component {

    getStateList = async() => {
        const {StateActions, language} = this.props;
        const { token, auth, loginUserNo } = this.props;

        try {
            if(auth === "ROLE_ADMIN") {
                await StateActions.getRecordStateList(token);
            }
            else{
                await StateActions.getRecordSearchStateList(null, null, null, null, null, true, loginUserNo, null, token, language);
            }
        } catch(e){
            console.log(e);
        }
    }

    componentWillMount() {
        if(window.sessionStorage.getItem("path")) {
            window.sessionStorage.removeItem("path");
        }
        window.sessionStorage.setItem("path", "/app/workAttitude/list");
        this.getStateList();
    }

    render() {
        const { tables, loading, language } =this.props;

        if(loading) return null;

        return (
            <div>
                <RecordState language={language} tables={tables}/>
            </div>
        );
    }
}

export default connect(
    (state) => ({
        tables: state.state.get('tables'),
        loading: state.pender.pending['state/RECORD_STATE_LIST'],
        token: state.login.token,
        auth: state.login.auth,
        loginUserNo: state.login.no,
        language: state.language.language
    }),
    (dispatch) => ({
        StateActions: bindActionCreators(stateActions, dispatch)
    })
)(RecordStateContainer);