export default {
    Normal: {
        "ko": "정상",
        "en": "Normal"
    },
    Error: {
        "ko": "에러",
        "en": "Error"
    },
    Lateness: {
        "ko": "지각",
        "en": "Lateness"
    },
    Early_leave: {
        "ko": "조퇴",
        "en": "Early leave"
    },
    Non_enregistrement: {
        "ko": "미등록",
        "en": "Non-enregistrement"
    },
    Non_process: {
        "ko": "미처리",
        "en": "Non-process"
    },
    Table: {
        "ko": "테이블",
        "en": "Table"
    },
    NormalWorkDay: {
        "ko": "정상 근로일",
        "en": "Normal Working Day"
    },
    Calendar: {
        "ko": "달력",
        "en": "Calendar"
    },
    Name: {
        "ko": "이름",
        "en": "Name"
    },
    Period: {
        "ko": "기간",
        "en": "Period"
    },
    Employee_name: {
        "ko": "사원 이름",
        "en": "Name"
    },
    Search: {
        "ko": "검색",
        "en": "Search"
    },
    Division: {
        "ko": "구분",
        "en": "Division"
    },
    All: {
        "ko": "전체",
        "en": "All"
    },
    Business_trip: {
        "ko": "출장",
        "en": "Business trip"
    },
    Work_outside: {
        "ko": "외근",
        "en": "Work outside"
    },
    Annual_leave: {
        "ko": "연차",
        "en": "Annual leave"
    },
    Semi_annual_leave: {
        "ko": "반차",
        "en": "Semi leave"
    },
    morningSemiAnnualLeave: {
        "ko": "오전반차",
        "en": "Morning leave"
    },
    afternoonSemiAnnualLeave: {
        "ko": "오후반차",
        "en": "Afternoon leave"
    },
    Education: {
        "ko": "교육",
        "en": "Education"
    },
    Start_date: {
        "ko": "시작 날짜",
        "en": "Start date"
    },
    End_date: {
        "ko": "끝 날짜",
        "en": "End date"
    },
    Date: {
        "ko": "날짜",
        "en": "Date"
    },
    holidayDate: {
        "ko": "휴일 날짜",
        "en": "Holiday Date"
    },
    startTime: {
        "ko": "시작 시간",
        "en": "Start Time"
    },
    endTime: {
        "ko": "끝 시간",
        "en": "End Time"
    },
    use: {
        "ko": "사용여부",
        "en": "Use"
    },
    holidayExplanation: {
        "ko": "휴일설명",
        "en": "Holyday Explanation"
    },
    breakTimeExplanation: {
        "ko": "휴게설명",
        "en": "BreakTime Explanation"
    },
    Apply_period: {
        "ko": "신청 기간",
        "en": "Application period"
    },
    ActiveAgent: {
        "ko": "활동 행위자",
        "en": "Active agent"
    },
    ActivePeriod: {
        "ko": "활동 기간",
        "en": "Active Period"
    },
    State: {
        "ko": "상태",
        "en": "State"
    },
    TotalWorkTime: {
        "ko": "총 근무시간",
        "en": "Total Working Time"
    },
    TotalWorkDay: {
        "ko": "총 근로일",
        "en": "Total Working Day"
    },
    Day: {
        "ko": "요일",
        "en": "Day"
    },
    WorkAttitudeContents: {
        "ko": "근태 내용",
        "en": "Contents"
    },
    WorkAttitudeItem: {
        "ko": "근태 항목",
        "en": "Item"
    },
    WorkAttitudeDivide: {
        "ko": "근태 구분",
        "en": "Division"
    },
    WorkAttitudeReason: {
        "ko": "근태 사유",
        "en": "Reason"
    },
    workAttitudePeriod: {
        "ko": "근태 기간",
        "en": "Period"
    },
    Title: {
        "ko": "제목",
        "en": "Title"
    },
    Submit: {
        "ko": "등록",
        "en": "Submit"
    },
    CommutePeriod: {
        "ko": "출근 기간",
        "en": "Commute period"
    },
    WorkState: {
        "ko": "출근 상태",
        "en": "Commute state"
    },
    CheckInTime: {
        "ko": "출근 시간",
        "en": "Check-In time"
    },
    CheckOutTime: {
        "ko": "퇴근 시간",
        "en": "Check-Out Time"
    },
    Id: {
        "ko": "아이디",
        "en": "ID"
    },
    Contents: {
        "ko": "내용",
        "en": "Contents"
    },
    Type: {
        "ko": "타입",
        "en": "Type"
    },
    ReadCheck: {
        "ko": "읽음 여부",
        "en": "Read Check"
    },
    Read: {
        "ko": "읽음",
        "en": "Read"
    },
    UnRead: {
        "ko": "읽지 않음",
        "en": "Unread"
    },
    alarmList: {
        "ko": "알람이 없습니다.",
        "en": "There is no alarm."
    },
    commuteManage: {
        "ko": "출퇴근 관리",
        "en": "Commute Manage"
    },
    commuteList: {
        "ko": "출퇴근 조회",
        "en": "List"
    },
    commuteApply: {
        "ko": "출퇴근 신청",
        "en": "Apply"
    },
    workAttitudeManage: {
        "ko": "근태 관리",
        "en": "Work Attitude Manage"
    },
    workAttitudeList: {
        "ko": "근태 조회",
        "en": "List"
    },
    workAttitudeApply: {
        "ko": "근태 신청",
        "en": "Apply"
    },
    activeRecord: {
        "ko": "활동 기록",
        "en": "Active Record"
    },
    serviceSetting: {
        "ko": "서비스 설정",
        "en": "Service Setting"
    },
    workTimeSetting: {
        "ko": "근무시간 설정",
        "en": "WorkTime Setting"
    },
    breakTimeSetting: {
        "ko": "휴게시간 설정",
        "en": "BreakTime Setting"
    },
    holidaySetting: {
        "ko": "휴일 설정",
        "en": "Holiday Setting"
    },
    goToWork: {
        "ko": "출근",
        "en": "Go to work"
    },
    getOffWork: {
        "ko": "퇴근",
        "en": "Get off work"
    },
    workAttitude: {
        "ko": "근태",
        "en": "Work Attitude"
    },
    loginTitle: {
        "ko": "로그인",
        "en": "Login"
    },
    commuteCheckTitle: {
        "ko": "출퇴근 신청",
        "en": "Commute Check"
    },
    commuteListTitle: {
        "ko": "출퇴근 조회",
        "en": "Commute List"
    },
    workAttitudeNewTitle: {
        "ko": "근태 신청",
        "en": "Work Attitude Apply"
    },
    workAttitudeListTitle: {  
        "ko": "근태 조회",
        "en": "Work Attitude List"
    },
    activeRecordTitle: {
        "ko": "활동 기록",
        "en": "Active Record"
    },
    breakTimeTitle: {
        "ko": "휴게시간 설정",
        "en": "Break Time Setting"
    },
    holidayTitle: {
        "ko": "휴일 설정",
        "en": "Holiday Setting"
    },
    workTimeTitle: {
        "ko": "근무시간 설정",
        "en": "Work Time Setting"
    },
    close: {
        "ko": "닫기",
        "en": "Close"
    },
    detailView: {
        "ko": "상세보기",
        "en": "Detail View"
    },
    modification: {
        "ko": "수정",
        "en": "modification"
    },
    modify: {
        "ko": "수정하기",
        "en": "Modify"
    },
    delete: {
        "ko": "삭제",
        "en": "Delete"
    },
    applicant: {
        "ko": "신청자",
        "en": "applicant"
    },
    language: {
        "ko": "다국어",
        "en": "Language"
    },
    Empty_Period: {
        "ko": '기간이 비어있습니다.',
        "en": "Period is empty."
    },
    Time_Longer: {
        "ko": '시작기간이 더 큽니다.',
        "en": "Start time is longer."
    },
    Empty_Subject: {
        "ko": '제목이 비어있습니다.',
        "en": "Subject is empty."
    },
    Empty_Present: {
        "ko": '근태사유가 비어있습니다.',
        "en": "The reason for the present condition is empty."
    },
    No_Date_GoTO: {
        "ko": '출근날짜가 없습니다.',
        "en": "There is no date to go to work."
    },
    No_Date_GoOff: {
        "ko": '퇴근날짜가 없습니다.',
        "en": "There is no work day."
    },
    Grerter_Than: {
        "ko": '출근날짜가 퇴근날짜보다 큽니다.',
        "en": "The date of the work is greater than the date of the work."
    },
    Detail: {//반대로 
        "en": '상세 페이지.',
        "ko": "Detail page."
    },
    Initialized: {
        "en": '다국어 선택시 입력이 초기화 됩니다. 다국어처리 하시겠습니까?',
        "ko": "When selecting multiple languages, input is initialized. Do you want multilingual processing?"
    },
    Confirm: {
        "en": '확인',
        "ko": "Confirm"
    },
    Cancel: {
        "en": '취소',
        "ko": "Cancel"
    },
    //
    Completed: {
        "ko": '출근 완료 (퇴근 가능:',
        "en": "Go to work completed (Can leave after: "
    },
    Sub_Completed: {
        "ko": '이후',
        "en": " "
    },
    Finished_Work: {
        "ko": '퇴근 완료 (자정 : 출근버튼 활성화)',
        "en": "Finished work (Midnight: Activate work button)"
    }
}